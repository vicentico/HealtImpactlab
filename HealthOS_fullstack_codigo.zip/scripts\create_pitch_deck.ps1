﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$output = Join-Path $root "HealthOS_Pitch_Deck_Claude_Impact_Lab_2026.pptx"
$logo = Join-Path $root "assets\healthos-logo.png"
$hospital = Join-Path $root "assets\mockup-hospital-desktop.png"
$cesfam = Join-Path $root "assets\mockup-cesfam-contralor.png"
$mobile = Join-Path $root "assets\mockup-mobile.png"

function RGB([int]$r,[int]$g,[int]$b) { return $r + 256*$g + 65536*$b }
$bg = RGB 3 17 31; $panel = RGB 8 35 53; $cyan = RGB 33 227 209
$white = RGB 238 250 255; $muted = RGB 137 166 181; $amber = RGB 255 192 94; $green = RGB 90 243 165

$ppt = New-Object -ComObject PowerPoint.Application
$ppt.Visible = -1
$deck = $ppt.Presentations.Add()
$deck.PageSetup.SlideWidth = 960
$deck.PageSetup.SlideHeight = 540

function Add-Text($slide,$text,$x,$y,$w,$h,$size=18,$color=$white,$bold=$false,$font="Aptos") {
  $shape = $slide.Shapes.AddTextbox(1,$x,$y,$w,$h)
  $shape.TextFrame2.TextRange.Text = $text
  $shape.TextFrame2.TextRange.Font.Name = $font
  $shape.TextFrame2.TextRange.Font.Size = $size
  $shape.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = $color
  $shape.TextFrame2.TextRange.Font.Bold = $(if($bold){-1}else{0})
  $shape.TextFrame2.MarginLeft = 0; $shape.TextFrame2.MarginRight = 0
  $shape.TextFrame2.MarginTop = 0; $shape.TextFrame2.MarginBottom = 0
  return $shape
}
function Add-Rect($slide,$x,$y,$w,$h,$color=$panel,$radius=$true) {
  $shape = $slide.Shapes.AddShape($(if($radius){5}else{1}),$x,$y,$w,$h)
  $shape.Fill.ForeColor.RGB = $color; $shape.Fill.Transparency = 0
  $shape.Line.ForeColor.RGB = RGB 29 87 108; $shape.Line.Transparency = 0.35
  return $shape
}
function Base-Slide($kicker,$title,$subtitle="") {
  $s = $deck.Slides.Add($deck.Slides.Count+1,12)
  $back = $s.Shapes.AddShape(1,0,0,960,540)
  $back.Fill.ForeColor.RGB = $bg; $back.Line.Visible = 0
  Add-Text $s $kicker 48 28 850 18 10 $cyan $true | Out-Null
  Add-Text $s $title 48 55 860 54 29 $white $true | Out-Null
  if($subtitle){ Add-Text $s $subtitle 48 112 850 34 14 $muted $false | Out-Null }
  Add-Text $s "HealthOS · HealthSolutions · Claude Impact Lab 2026" 48 514 700 14 8 $muted $false | Out-Null
  Add-Text $s ([string]$deck.Slides.Count) 900 514 20 14 8 $muted $false | Out-Null
  return $s
}
function Add-Card($s,$title,$body,$x,$y,$w,$h,$accent=$cyan) {
  Add-Rect $s $x $y $w $h | Out-Null
  Add-Text $s $title ($x+18) ($y+16) ($w-36) 24 15 $accent $true | Out-Null
  Add-Text $s $body ($x+18) ($y+48) ($w-36) ($h-62) 12 $white $false | Out-Null
}

# 1 Cover
$s = $deck.Slides.Add(1,12)
$back = $s.Shapes.AddShape(1,0,0,960,540); $back.Fill.ForeColor.RGB = $bg; $back.Line.Visible = 0
$s.Shapes.AddPicture($logo,0,-1,48,62,100,100) | Out-Null
Add-Text $s "HEALTHSOLUTIONS · LONGEVIDAD / LÍNEA 2" 48 28 760 20 11 $cyan $true | Out-Null
Add-Text $s "HealthOS" 48 180 560 70 48 $white $true | Out-Null
Add-Text $s "El sistema operativo para convertir listas de espera en rutas de atención priorizadas, explicables y accionables." 48 252 700 90 24 $white $true | Out-Null
Add-Text $s "Claude Impact Lab 2026 · MVP funcional con datos 100% sintéticos" 48 386 700 24 13 $muted $false | Out-Null
Add-Rect $s 760 55 150 400 (RGB 5 44 59) | Out-Null
$s.Shapes.AddPicture($mobile,0,-1,790,76,90,355) | Out-Null

# 2 Pain
$s = Base-Slide "01 · DOLOR" "La lista existe. La decisión no." "En CESFAM y hospitales, gran parte del trabajo sigue siendo manual, fragmentado y difícil de auditar."
Add-Card $s "Cola pasiva" "El orden administrativo no siempre representa el riesgo clínico ni la antigüedad de forma equilibrada." 48 170 270 250 $amber
Add-Card $s "Capacidad invisible" "Reordenar no reduce la espera. Los cupos, no-show y recursos se gestionan sin una simulación común." 345 170 270 250 $cyan
Add-Card $s "Trazabilidad débil" "Jefatura, contralor, médico y enfermería coordinan por planillas, llamadas y revisiones difíciles de escalar." 642 170 270 250 $green

# 3 Solution
$s = Base-Slide "02 · SOLUCIÓN" "HealthOS convierte una cola en un sistema operacional." "El profesional mantiene la decisión; el software hace visible el riesgo, la razón y la capacidad."
Add-Card $s "1 · Prioriza" "Score auditable: riesgo clínico + antigüedad. Cada movimiento conserva posición anterior, nueva posición y factores visibles." 48 166 270 272 $cyan
Add-Card $s "2 · Coordina" "Flujos por rol: contralor APS, jefatura, medicina y enfermería. Copiloto local sin text-to-SQL." 345 166 270 272 $green
Add-Card $s "3 · Simula" "Capacidad adicional, cupos recuperables y efecto esperado sobre la espera global, separado del orden clínico." 642 166 270 272 $amber

# 4 Product
$s = Base-Slide "03 · PRODUCTO FUNCIONAL" "De planillas a torre de control en una sola aplicación local." "Demo ejecutable para Windows; web responsive y base adaptable a iOS/Android."
$s.Shapes.AddPicture($hospital,0,-1,48,150,864,330) | Out-Null

# 5 Two editions
$s = Base-Slide "04 · DOS PUERTAS DE ENTRADA" "Un motor; dos problemas operacionales." "La misma base tecnológica se configura según el lugar donde hoy ocurre el trabajo manual."
Add-Rect $s 48 156 416 310 | Out-Null
Add-Text $s "CESFAM CONTRALOR" 68 176 360 24 16 $cyan $true | Out-Null
$s.Shapes.AddPicture($cesfam,0,-1,68,214,376,190) | Out-Null
Add-Text $s "Derivaciones APS · cumplimiento · trazabilidad · escalamiento" 68 418 365 34 11 $white $false | Out-Null
Add-Rect $s 496 156 416 310 | Out-Null
Add-Text $s "HOSPITAL OPERACIONES" 516 176 360 24 16 $amber $true | Out-Null
$s.Shapes.AddPicture($hospital,0,-1,516,214,376,190) | Out-Null
Add-Text $s "Priorización clínica · capacidad · coordinación de equipos" 516 418 365 34 11 $white $false | Out-Null

# 6 Differentiation
$s = Base-Slide "05 · DIFERENCIACIÓN" "No reemplaza el HIS: lo vuelve accionable." "Posicionamiento frente a planillas, agenda, BI clínico y soluciones puntuales de IA."
$rows = @(
  @("Capacidad + priorización separadas","HealthOS: Sí","Alternativas: Parcial"),
  @("Explicación por paciente y rol","HealthOS: Sí","Alternativas: Variable"),
  @("Local-first / soberanía de datos","HealthOS: Sí","Alternativas: Variable"),
  @("Flujo jefatura → clínico → enfermería","HealthOS: Sí","Alternativas: Fragmentado"),
  @("FHIR/TEI mediante bridge autorizado","HealthOS: Preparado","Alternativas: Integración específica")
)
$y=162
foreach($r in $rows){ Add-Rect $s 48 $y 864 52 | Out-Null; Add-Text $s $r[0] 66 ($y+16) 385 22 12 $white $true | Out-Null; Add-Text $s $r[1] 478 ($y+16) 190 22 12 $green $true | Out-Null; Add-Text $s $r[2] 690 ($y+16) 195 22 12 $muted $false | Out-Null; $y+=58 }

# 7 Business model
$s = Base-Slide "06 · MODELO DE NEGOCIO" "B2G/B2B: entrar por piloto, escalar por red." "No monetizamos por paciente priorizado: evitamos incentivos contrarios a la equidad clínica."
Add-Card $s "Piloto pagado" "Diagnóstico del proceso, configuración, validación retrospectiva y métricas de línea base." 48 170 200 245 $cyan
Add-Card $s "Licencia anual" "SaaS privado u on-premise por establecimiento/red y volumen operacional." 270 170 200 245 $green
Add-Card $s "Integración" "FHIR/TEI, bridge institucional, SSO, capacitación, soporte y ciberseguridad." 492 170 200 245 $amber
Add-Card $s "Módulos" "Analítica, coordinación de cupos e IA clínica solo después de validación." 714 170 198 245 $cyan

# 8 Go-to-market
$s = Base-Slide "07 · GO-TO-MARKET" "Primero evidencia; después escala." "TAM/SAM/SOM y precio se completan con fuentes verificadas y disposición a pagar; no se inventan antes del discovery."
Add-Card $s "0–3 meses" "2 entrevistas clave + mapeo de proceso + selección de red piloto + DPIA inicial." 48 170 270 240 $cyan
Add-Card $s "3–9 meses" "Piloto retrospectivo/prospectivo con comité clínico, métricas, sesgo y plan de reversión." 345 170 270 240 $green
Add-Card $s "9–18 meses" "Contrato por red, integración autorizada, firma de software, soporte y expansión territorial." 642 170 270 240 $amber

# 9 Moat
$s = Base-Slide "08 · MOAT, IP Y CONFIANZA" "Lo defendible es la capa operacional y su evidencia." "No afirmamos patente, eficacia clínica ni conformidad oficial sin estudio y validación."
Add-Card $s "IP" "Marca y derecho de autor; secreto empresarial sobre taxonomía, calibración, reglas y arquitectura. Búsqueda de anterioridad pendiente." 48 170 270 250 $cyan
Add-Card $s "Seguridad" "RBAC, JWT local, bots aislados, sin text-to-SQL, URLs internas, datos sintéticos y auditoría." 345 170 270 250 $green
Add-Card $s "Escalabilidad" "API modular, despliegue local o privado, bridges de interoperabilidad y una base multiplataforma." 642 170 270 250 $amber

# 10 Ask
$s = Base-Slide "09 · ASK" "Buscamos un sitio piloto y aliados para validar impacto." "HealthOS ya demuestra el flujo; el siguiente activo es evidencia operacional y clínica responsable."
Add-Text $s "Lo que aportamos" 48 174 260 24 16 $cyan $true | Out-Null
Add-Text $s "• MVP funcional con 10.000 registros sintéticos`n• Dos ejecutables Windows por contexto`n• Motor explicable, simulador y copiloto local`n• Arquitectura preparada para interoperabilidad" 48 214 380 180 15 $white $false | Out-Null
Add-Text $s "Lo que necesitamos" 520 174 300 24 16 $amber $true | Out-Null
Add-Text $s "• Contraparte clínica y técnica`n• Acceso a proceso y datos autorizados`n• Definición conjunta de métricas y SLA`n• Piloto con gobernanza, seguridad y reversibilidad" 520 214 380 180 15 $white $false | Out-Null
Add-Rect $s 48 426 852 54 (RGB 6 56 66) | Out-Null
Add-Text $s "HealthOS: que la espera deje de ser una lista y se convierta en una decisión responsable." 70 442 810 22 16 $white $true | Out-Null

$deck.SaveAs($output)
$deck.Close()
$ppt.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($deck) | Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($ppt) | Out-Null
Write-Output $output
