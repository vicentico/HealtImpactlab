from __future__ import annotations

import argparse
import math
import random
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from faker import Faker

SEED = 20260805

INSTITUTIONS = [
    ("INST-001", "Hospital Sintético Norte Grande", "Arica y Parinacota"),
    ("INST-002", "Hospital Sintético Antofagasta", "Antofagasta"),
    ("INST-003", "Hospital Sintético Atacama", "Atacama"),
    ("INST-004", "Hospital Sintético Coquimbo", "Coquimbo"),
    ("INST-005", "Hospital Sintético Valparaíso", "Valparaíso"),
    ("INST-006", "Hospital Sintético Metropolitano Norte", "Metropolitana"),
    ("INST-007", "Hospital Sintético Metropolitano Sur", "Metropolitana"),
    ("INST-008", "Hospital Sintético O'Higgins", "O'Higgins"),
    ("INST-009", "Hospital Sintético Maule", "Maule"),
    ("INST-010", "Hospital Sintético Ñuble", "Ñuble"),
    ("INST-011", "Hospital Sintético Biobío", "Biobío"),
    ("INST-012", "Hospital Sintético Araucanía", "La Araucanía"),
    ("INST-013", "Hospital Sintético Los Ríos", "Los Ríos"),
    ("INST-014", "Hospital Sintético Los Lagos", "Los Lagos"),
    ("INST-015", "Hospital Sintético Austral", "Magallanes"),
]

COMORBIDITIES = [
    "Hipertensión",
    "Obesidad",
    "Dislipidemia",
    "Enfermedad Renal Crónica",
    "Enfermedad Cardiovascular",
    "Neuropatía",
    "Retinopatía",
]


def rut_check_digit(number: int) -> str:
    reversed_digits = map(int, reversed(str(number)))
    factors = [2, 3, 4, 5, 6, 7]
    total = sum(digit * factors[index % len(factors)] for index, digit in enumerate(reversed_digits))
    result = 11 - (total % 11)
    if result == 11:
        return "0"
    if result == 10:
        return "K"
    return str(result)


def synthetic_rut(index: int) -> str:
    # Prefix prevents accidental treatment as a real Chilean identifier.
    number = 90_000_000 + index
    return f"SYN-{number}-{rut_check_digit(number)}"


def sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-value))


def choose_comorbidities(rng: np.random.Generator, age: int, hba1c: float) -> list[str]:
    age_factor = max(0, age - 45) / 45
    poor_control = max(0.0, hba1c - 7.0) / 5.0
    probabilities = {
        "Hipertensión": min(0.85, 0.30 + 0.42 * age_factor),
        "Obesidad": min(0.72, 0.36 + 0.10 * poor_control),
        "Dislipidemia": min(0.70, 0.28 + 0.28 * age_factor),
        "Enfermedad Renal Crónica": min(0.42, 0.04 + 0.18 * age_factor + 0.12 * poor_control),
        "Enfermedad Cardiovascular": min(0.35, 0.03 + 0.18 * age_factor + 0.08 * poor_control),
        "Neuropatía": min(0.48, 0.05 + 0.16 * age_factor + 0.18 * poor_control),
        "Retinopatía": min(0.42, 0.04 + 0.13 * age_factor + 0.18 * poor_control),
    }
    selected = [name for name, probability in probabilities.items() if rng.random() < probability]
    return selected or [rng.choice(["Hipertensión", "Obesidad", "Dislipidemia"]).item()]


def foot_risk_and_wagner(
    rng: np.random.Generator,
    age: int,
    hba1c: float,
    comorbidities: list[str],
) -> tuple[float, int]:
    linear = -2.8 + 0.23 * (hba1c - 7) + 0.018 * max(0, age - 45)
    if "Neuropatía" in comorbidities:
        linear += 1.0
    if "Enfermedad Renal Crónica" in comorbidities:
        linear += 0.45
    linear += rng.normal(0, 0.55)
    risk = float(np.clip(sigmoid(linear), 0.01, 0.99))

    if risk < 0.22:
        stage_probs = [0.93, 0.06, 0.01, 0.0, 0.0, 0.0]
    elif risk < 0.42:
        stage_probs = [0.55, 0.32, 0.10, 0.03, 0.0, 0.0]
    elif risk < 0.65:
        stage_probs = [0.18, 0.34, 0.31, 0.13, 0.03, 0.01]
    elif risk < 0.82:
        stage_probs = [0.05, 0.18, 0.34, 0.28, 0.11, 0.04]
    else:
        stage_probs = [0.01, 0.05, 0.18, 0.34, 0.27, 0.15]
    wagner = int(rng.choice(np.arange(6), p=stage_probs))
    return round(risk, 4), wagner


def ecicep_stratum(comorbidities: list[str]) -> str:
    # DM2 is the base chronic condition; the remaining conditions are synthetic comorbidities.
    chronic_condition_count = 1 + len(comorbidities)
    if chronic_condition_count >= 5:
        return "G3"
    if chronic_condition_count >= 2:
        return "G2"
    return "G1"


def route_for(comorbidities: list[str], wagner: int, foot_risk: float) -> str:
    if wagner >= 1 or foot_risk >= 0.62:
        return "Pie diabético"
    if "Enfermedad Renal Crónica" in comorbidities:
        return "Nefrología"
    if "Retinopatía" in comorbidities:
        return "Oftalmología"
    return "Diabetología"


def generate_dataset(count: int, output_path: Path) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    random.seed(SEED)
    fake = Faker("es_CL")
    Faker.seed(SEED)
    today = date.today()

    rows: list[dict[str, object]] = []
    institution_weights = np.array([0.035, 0.05, 0.04, 0.055, 0.08, 0.15, 0.14, 0.07, 0.07, 0.045, 0.08, 0.065, 0.045, 0.055, 0.02])
    institution_weights = institution_weights / institution_weights.sum()

    for index in range(1, count + 1):
        institution_index = int(rng.choice(len(INSTITUTIONS), p=institution_weights))
        institution_id, institution_name, region = INSTITUTIONS[institution_index]

        age = int(np.clip(rng.normal(63, 12), 30, 95))
        hba1c = float(np.clip(rng.normal(7.9 + max(0, age - 70) * 0.006, 1.45), 5.2, 14.5))
        comorbidities = choose_comorbidities(rng, age, hba1c)
        foot_risk, wagner = foot_risk_and_wagner(rng, age, hba1c, comorbidities)

        # Long-tailed waiting time, capped to 4 years for the synthetic demo.
        wait_days = int(np.clip(rng.lognormal(mean=5.05, sigma=0.82), 3, 1460))
        last_visit_days = int(np.clip(rng.lognormal(mean=4.25, sigma=0.75), 1, 900))
        hypoglycemia_risk = float(
            np.clip(0.12 + 0.05 * max(0, 7.0 - hba1c) + rng.beta(1.4, 6.5), 0.01, 0.98)
        )
        no_show_risk = float(
            np.clip(0.08 + 0.00035 * wait_days + rng.beta(1.2, 5.0) * 0.55, 0.01, 0.95)
        )
        sex = rng.choice(["F", "M"], p=[0.53, 0.47]).item()
        name = fake.name_female() if sex == "F" else fake.name_male()
        synthetic_id = synthetic_rut(index)

        rows.append(
            {
                "RUT_Sintetico": synthetic_id,
                "Nombre_Sintetico": name,
                "Edad": age,
                "Sexo_Sintetico": sex,
                "Fecha_Inscripcion_Lista": (today - timedelta(days=wait_days)).isoformat(),
                "Synthetic_HbA1c": round(hba1c, 1),
                "Comorbilidades_Sinteticas": "|".join(comorbidities),
                "Estrato_ECICEP_Sintetico": ecicep_stratum(comorbidities),
                "Ultima_Visita_Hospital_Sintetica": (today - timedelta(days=last_visit_days)).isoformat(),
                "Institucion_ID": institution_id,
                "Institucion_Nombre": institution_name,
                "Region": region,
                "Ubicacion_Sintetica_PieDiabetico_ImageURL": (
                    f"synthetic://healthos/diabetic-foot/{synthetic_id.lower()}"
                ),
                "Riesgo_Pie_Diabetico_Sintetico": foot_risk,
                "Wagner_Sintetico": wagner,
                "Riesgo_Hipoglicemia_Sintetico": round(hypoglycemia_risk, 4),
                "No_Show_Risk_Sintetico": round(no_show_risk, 4),
                "Ruta_Sugerida": route_for(comorbidities, wagner, foot_risk),
                "Data_Classification": "SYNTHETIC_OPERATIONAL",
                "Synthetic_Seed": SEED,
            }
        )

    frame = pd.DataFrame(rows)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_path, index=False)
    frame.to_json(output_path.with_suffix(".json"), orient="records", force_ascii=False)

    summary = (
        frame.groupby(["Institucion_ID", "Institucion_Nombre", "Region"], as_index=False)
        .agg(
            Pacientes=("RUT_Sintetico", "count"),
            HbA1c_Media=("Synthetic_HbA1c", "mean"),
            Wagner_Medio=("Wagner_Sintetico", "mean"),
        )
    )
    summary.to_csv(output_path.with_name("institution_summary_synthetic.csv"), index=False)
    ecicep_summary = (
        frame.groupby(["Institucion_ID", "Estrato_ECICEP_Sintetico"], as_index=False)
        .agg(Pacientes=("RUT_Sintetico", "count"))
    )
    ecicep_summary.to_csv(output_path.with_name("ecicep_summary_synthetic.csv"), index=False)
    return frame


def main() -> None:
    parser = argparse.ArgumentParser(description="Genera pacientes DM2 sintéticos para HealthOS")
    parser.add_argument("--count", type=int, default=10_000)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).parent / "output" / "patients_dm2_synthetic.csv",
    )
    args = parser.parse_args()
    if args.count < 1 or args.count > 1_000_000:
        raise SystemExit("--count debe estar entre 1 y 1.000.000")
    frame = generate_dataset(args.count, args.output)
    print(f"Dataset generado: {len(frame):,} filas -> {args.output}")
    print("Todos los identificadores comienzan con SYN- y los datos son ficticios.")


if __name__ == "__main__":
    main()
