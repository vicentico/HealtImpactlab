$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot

Set-Location $ProjectRoot
python -m pip install -r requirements-desktop.txt
$TempBuild = Join-Path $env:LOCALAPPDATA "Temp\healthos-pyinstaller-build"
$TempDist = Join-Path $env:LOCALAPPDATA "Temp\healthos-pyinstaller-dist"
$CommonArgs = @(
  "--noconfirm", "--onedir", "--windowed",
  "--paths", $ProjectRoot,
  "--workpath", $TempBuild,
  "--distpath", $TempDist,
  "--collect-all", "orjson",
  "--hidden-import", "collections.abc",
  "--hidden-import", "webview.platforms.edgechromium",
  "--exclude-module", "pandas",
  "--exclude-module", "numpy",
  "--exclude-module", "torch",
  "--exclude-module", "PySide6",
  "--exclude-module", "PyQt6",
  "--exclude-module", "PyQt5",
  "--exclude-module", "cefpython3",
  "--exclude-module", "wx",
  "--add-data", "src/desktop_web;src/desktop_web",
  "--add-data", "src/data/output/patients_dm2_synthetic.csv;src/data/output",
  "--add-data", "LICENSE-PROPRIETARY.txt;.",
  "--icon", "assets/healthos-logo.ico"
)

python -m PyInstaller @CommonArgs --name HealthOS-CESFAM-Contralor src/backend/desktop_launcher.py
python -m PyInstaller @CommonArgs --name HealthOS-Hospital-Operaciones src/backend/desktop_launcher.py

$OutputDir = Join-Path $ProjectRoot "dist"
$CesfamOutput = Join-Path $OutputDir "HealthOS-CESFAM-Contralor"
$HospitalOutput = Join-Path $OutputDir "HealthOS-Hospital-Operaciones"
if ((Split-Path -Parent $CesfamOutput) -ne $OutputDir -or (Split-Path -Parent $HospitalOutput) -ne $OutputDir) {
  throw "Destino de compilación no válido"
}
Remove-Item -LiteralPath $CesfamOutput -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $HospitalOutput -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $TempDist "HealthOS-CESFAM-Contralor") -Destination $OutputDir -Recurse -Force
Copy-Item -Path (Join-Path $TempDist "HealthOS-Hospital-Operaciones") -Destination $OutputDir -Recurse -Force

Compress-Archive -Path "dist/HealthOS-CESFAM-Contralor/*" -DestinationPath "dist/HealthOS-CESFAM-Contralor-portable.zip" -Force
Compress-Archive -Path "dist/HealthOS-Hospital-Operaciones/*" -DestinationPath "dist/HealthOS-Hospital-Operaciones-portable.zip" -Force

Write-Host "Ejecutables creados en dist/"
