from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import httpx

from src.backend.config import get_settings


class RayenBridgeError(RuntimeError):
    pass


class APSBridge(Protocol):
    async def fetch_synthetic_referrals(self, institution_id: str) -> list[dict[str, Any]]: ...


@dataclass
class DisabledRayenBridge:
    """Default adapter: explicit refusal prevents an accidental or invented integration."""

    async def fetch_synthetic_referrals(self, institution_id: str) -> list[dict[str, Any]]:
        raise RayenBridgeError(
            "Bridge Rayen deshabilitado. HealthOS no asume una API pública de Rayen. "
            "Se requiere convenio, especificación técnica y pruebas de seguridad del proveedor/servicio de salud."
        )


@dataclass
class LocalRayenBridge:
    """
    Contract for an on-premise adapter controlled by the health service.

    The bridge is expected to expose only normalized, authorized data. HealthOS never stores
    Rayen credentials in the browser and never calls a CESFAM system directly from the frontend.
    """

    base_url: str
    timeout_seconds: float = 5.0

    async def fetch_synthetic_referrals(self, institution_id: str) -> list[dict[str, Any]]:
        if not institution_id.startswith("INST-"):
            raise RayenBridgeError("Identificador de institución inválido")
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            response = await client.get(
                f"{self.base_url.rstrip('/')}/v1/referrals",
                params={"institution_id": institution_id, "data_mode": "synthetic"},
                headers={"X-HealthOS-Purpose": "waitlist-prioritization-demo"},
            )
            response.raise_for_status()
            payload = response.json()
        if not isinstance(payload, list):
            raise RayenBridgeError("Respuesta del bridge inválida")
        return payload[:5000]


def get_rayen_bridge() -> APSBridge:
    settings = get_settings()
    if not settings.rayen_bridge_enabled:
        return DisabledRayenBridge()
    return LocalRayenBridge(settings.rayen_bridge_url)
