from __future__ import annotations

import math
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, ORJSONResponse
from fastapi.staticfiles import StaticFiles

from src.backend.ai_models.foot_vision import DiabeticFootVisionWrapper
from src.backend.chatbots.local_chat_safe import local_list_chat
from src.backend.chatbots.public_foot_chat_app import public_foot_chat
from src.backend.epidemiology import national_dm2_waitlist_summary
from src.backend.prioritization_engine import prioritize_patients, queue_metrics
from src.backend.repository import SyntheticPatientRepository
from src.backend.schemas import (
    CapacitySimulationRequest,
    ChatRequest,
    ChatResponse,
    FootClassifyRequest,
    FootClassifyResponse,
    PrioritizeRequest,
    PrioritizeResponse,
    Role,
)
from src.backend.security.auth import (
    CurrentUser,
    create_demo_token,
    get_current_user,
    require_roles,
)
from src.backend.security.middleware import LocalRateLimitMiddleware, SecurityHeadersMiddleware


def runtime_path(relative: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
    return base / relative


dataset_path = Path(
    os.getenv("HEALTHOS_DATASET_PATH", str(runtime_path("src/data/output/patients_dm2_synthetic.csv")))
)
frontend_dist = Path(os.getenv("HEALTHOS_FRONTEND_DIST", str(runtime_path("src/desktop_web"))))
repository = SyntheticPatientRepository(dataset_path)
vision_model = DiabeticFootVisionWrapper(os.getenv("HEALTHOS_MODEL_PATH", ""))

app = FastAPI(
    title="HealthOS DM2 Prioriza",
    version="1.0.0-demo",
    default_response_class=ORJSONResponse,
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(LocalRateLimitMiddleware, requests_per_minute=240)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.get("/health")
def health() -> dict[str, str]:
    return {
        "status": "ok",
        "service": "healthos-desktop",
        "dataset": "synthetic",
        "vision_mode": vision_model.mode,
    }


@app.get("/api/config")
def edition_config() -> dict[str, str]:
    edition = os.getenv("HEALTHOS_EDITION", "hospital_operaciones")
    if edition == "cesfam_contralor":
        return {
            "edition": edition,
            "product_name": "HealthOS CESFAM Contralor",
            "headline": "Centro de control de derivaciones APS",
            "subtitle": "Cumplimiento, trazabilidad y priorización para reducir espera evitable.",
        }
    return {
        "edition": edition,
        "product_name": "HealthOS Hospital Operaciones",
        "headline": "Torre de control hospitalaria DM2",
        "subtitle": "Prioriza riesgo, coordina equipos y transforma trabajo manual en capacidad accionable.",
    }


@app.get("/api/epidemiology/summary")
def epidemiology_summary() -> dict[str, object]:
    return national_dm2_waitlist_summary()


@app.get("/api/license")
def license_notice() -> dict[str, str]:
    return {
        "owner": "Health Solutions",
        "name": "Licencia propietaria exclusiva HealthOS",
        "copyright": "Copyright © 2026 Health Solutions. Todos los derechos reservados.",
        "scope": "Uso, copia, distribución o comercialización requieren autorización escrita.",
        "program_context": "Desarrollado por Health Solutions en el contexto de Claude Impact Lab 2026.",
        "clinical_notice": "Demostración con datos sintéticos; no constituye diagnóstico ni dispositivo médico.",
    }


@app.post("/api/auth/demo-token")
def demo_token(role: Role, institution_id: str | None = "INST-001") -> dict[str, str]:
    return {
        "access_token": create_demo_token(f"demo-{role.value}", role, institution_id),
        "token_type": "bearer",
        "role": role.value,
    }


@app.post("/api/prioritize", response_model=PrioritizeResponse)
def prioritize(
    request: PrioritizeRequest,
    user: Annotated[CurrentUser, Depends(get_current_user)],
) -> PrioritizeResponse:
    institution_id = request.institution_id
    if user.role != Role.JEFATURA_DM2:
        institution_id = user.institution_id
    ranked = prioritize_patients(
        repository.list_patients(institution_id), request.risk_weight, request.waiting_weight
    )
    return PrioritizeResponse(
        generated_at=datetime.now(timezone.utc),
        distinction=(
            "Priorizar redistribuye los cupos hacia mayor riesgo y antigüedad; "
            "aumentar capacidad es lo que reduce la espera global estimada."
        ),
        total_candidates=len(ranked),
        patients=ranked[: request.limit],
        metrics=queue_metrics(ranked),
    )


@app.post("/api/simulate_capacity")
def simulate_capacity(
    request: CapacitySimulationRequest,
    user: Annotated[CurrentUser, Depends(require_roles(Role.JEFATURA_DM2))],
) -> dict[str, float | int | str]:
    queue_size = repository.count_by_institution(request.institution_id)
    baseline = (
        request.current_doctors
        * request.appointments_per_doctor_per_day
        * request.workdays_per_week
    )
    scenario = (
        (request.current_doctors + request.additional_doctors)
        * request.appointments_per_doctor_per_day
        * request.workdays_per_week
    )

    def estimate(capacity: int) -> float:
        net = capacity - request.weekly_new_entries
        return math.inf if net <= 0 else round((queue_size / net) * 7, 1)

    before, after = estimate(baseline), estimate(scenario)
    reduction = (
        round((before - after) / before * 100, 1)
        if math.isfinite(before) and math.isfinite(after) and before > 0
        else 0.0
    )
    return {
        "queue_size": queue_size,
        "additional_doctors": request.additional_doctors,
        "baseline_weekly_capacity": baseline,
        "scenario_weekly_capacity": scenario,
        "estimated_global_wait_days_before": before if math.isfinite(before) else "creciente/sin equilibrio",
        "estimated_global_wait_days_after": after if math.isfinite(after) else "creciente/sin equilibrio",
        "estimated_reduction_percent": reduction,
        "recoverable_slots_per_week": request.additional_doctors
        * request.appointments_per_doctor_per_day
        * request.workdays_per_week,
        "interpretation": "Simulación operacional; no constituye un pronóstico hospitalario validado.",
    }


@app.post("/api/diabetic_foot/classify", response_model=FootClassifyResponse)
def classify_foot(
    request: FootClassifyRequest,
    _user: Annotated[
        CurrentUser,
        Depends(require_roles(Role.JEFATURA_DM2, Role.MEDICO, Role.ENFERMERIA)),
    ],
) -> FootClassifyResponse:
    try:
        return vision_model.classify_url(request.synthetic_image_url)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/chat/local-list", response_model=ChatResponse)
async def local_chat(
    request: ChatRequest,
    user: Annotated[
        CurrentUser,
        Depends(require_roles(Role.JEFATURA_DM2, Role.MEDICO, Role.ENFERMERIA)),
    ],
) -> ChatResponse:
    return await local_list_chat(request, user, repository)


@app.post("/api/chat/public-foot", response_model=ChatResponse)
def public_chat(request: ChatRequest) -> ChatResponse:
    return public_foot_chat(request)


if frontend_dist.exists():
    assets_dir = frontend_dist / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        candidate = (frontend_dist / full_path).resolve()
        if candidate.is_file() and frontend_dist.resolve() in candidate.parents:
            return FileResponse(candidate)
        return FileResponse(frontend_dist / "index.html")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=int(os.getenv("HEALTHOS_PORT", "8765")))
