# Informe de validación del artefacto

Fecha de generación: 2026-08-05

## Verificaciones completadas

- Dataset reproducible generado: **10.000 pacientes DM2 sintéticos** y **15 instituciones sintéticas**.
- Identificadores únicos con prefijo `SYN-`.
- Archivo agregado por institución y resumen ECICEP sintético generados.
- Pruebas automatizadas Python: **7/7 aprobadas**.
- Smoke test del motor: `/api/prioritize` procesó 10.000 candidatos.
- Smoke test de capacidad: el escenario de demostración respondió correctamente.
- Smoke test del wrapper de pie diabético: inferencia sintética determinística correcta.
- Smoke test de chat local y chat público aislado: correcto.
- Sintaxis JSX de `App.js` y `main.jsx`: validada mediante transpilación TypeScript.
- `docker-compose.yml`: YAML parseado correctamente.
- Búsqueda de identidad anterior: no se encontraron marcas ajenas a HealthOS.
- Búsqueda de recursos gráficos: el repositorio no incluye PNG, JPG, SVG ni imágenes generadas.

## Limitaciones de la validación en este entorno

- No se ejecutó `docker compose up` porque el binario Docker no está disponible en el entorno de generación.
- No se ejecutó el build final de Vite porque el mirror NPM del entorno no contiene paquetes React/Vite. La sintaxis JSX sí fue validada. En una máquina con acceso al registro NPM normal, ejecute `npm install && npm run build`.
- El wrapper CNN no incluye pesos clínicos reales: por defecto opera en modo sintético determinístico.
- La integración Rayen está deshabilitada y no asume una API pública o contrato no entregado.
