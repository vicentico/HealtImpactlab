from __future__ import annotations

import os
import sys
import threading
import time
import urllib.request
import webbrowser

if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")

import uvicorn

executable_name = os.path.basename(sys.executable).lower()
os.environ.setdefault(
    "HEALTHOS_EDITION",
    "cesfam_contralor" if "cesfam" in executable_name else "hospital_operaciones",
)

from src.backend.desktop_server import app

PORT = 8876


def open_when_ready() -> None:
    for _ in range(100):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=0.4):
                if os.getenv("HEALTHOS_NO_BROWSER") != "1":
                    webbrowser.open(f"http://127.0.0.1:{PORT}")
                return
        except Exception:
            time.sleep(0.2)


if __name__ == "__main__":
    threading.Thread(target=open_when_ready, daemon=True).start()
    uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="warning")
