from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from src.backend.schemas import PatientRecord


def patient_to_synthetic_fhir_bundle(patient: PatientRecord) -> dict[str, Any]:
    """
    Minimal FHIR R4-shaped demonstration mapping inspired by MINSAL TEI concepts.
    It is not an official conformance implementation and contains only synthetic data.
    """
    patient_ref = f"Patient/{patient.rut_sintetico}"
    service_request_id = f"sr-{patient.rut_sintetico}"
    return {
        "resourceType": "Bundle",
        "type": "collection",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "meta": {"tag": [{"system": "https://healthos.local/classification", "code": "synthetic"}]},
        "entry": [
            {
                "resource": {
                    "resourceType": "Patient",
                    "id": patient.rut_sintetico,
                    "identifier": [
                        {
                            "system": "https://healthos.local/synthetic-id",
                            "value": patient.rut_sintetico,
                        }
                    ],
                    "name": [{"text": patient.nombre_sintetico}],
                    "extension": [
                        {
                            "url": "https://healthos.local/fhir/StructureDefinition/data-classification",
                            "valueCode": "SYNTHETIC_OPERATIONAL",
                        }
                    ],
                }
            },
            {
                "resource": {
                    "resourceType": "ServiceRequest",
                    "id": service_request_id,
                    "status": "active",
                    "intent": "order",
                    "subject": {"reference": patient_ref},
                    "authoredOn": patient.fecha_inscripcion_lista.isoformat(),
                    "performer": [
                        {
                            "identifier": {
                                "system": "https://healthos.local/institution-id",
                                "value": patient.institucion_id,
                            },
                            "display": patient.institucion_nombre,
                        }
                    ],
                    "reasonCode": [{"text": patient.route_sugerida}],
                    "note": [{"text": "Registro sintético de demostración; no enviar a sistemas reales."}],
                }
            },
        ],
    }
