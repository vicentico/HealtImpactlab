using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Launch("cesfam_contralor");
    }

    private static void Launch(string edition)
    {
        string directory = AppDomain.CurrentDomain.BaseDirectory;
        string engine = Path.Combine(directory, "HealthOS-Engine.exe");
        if (!File.Exists(engine))
        {
            MessageBox.Show("Falta HealthOS-Engine.exe. Extraiga el ZIP completo antes de abrir la app.", "HealthOS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        Process.Start(new ProcessStartInfo
        {
            FileName = engine,
            Arguments = "--edition=" + edition,
            WorkingDirectory = directory,
            UseShellExecute = true
        });
    }
}
