# HealthOS DM2 Prioriza

Plataforma demostrativa **local-first** para reestructurar listas de espera de personas con Diabetes Mellitus Tipo 2, explicar cada cambio de posición, simular capacidad adicional y apoyar la derivación de pie diabético mediante una arquitectura preparada para visión artificial.

> **Alcance del repositorio:** MVP técnico y de investigación con datos 100% sintéticos. No es un dispositivo médico, no entrega diagnóstico, no reemplaza el juicio clínico y no debe conectarse a sistemas reales sin convenio, evaluación de impacto, validación clínica, pruebas de interoperabilidad y revisión de ciberseguridad.

## Principio central

- **Priorizar** cambia el orden y distribuye los cupos hacia mayor riesgo y antigüedad.
- **Agregar capacidad** puede reducir el tiempo global y el volumen acumulado.
- El motor mantiene estos dos efectos separados en `/api/prioritize` y `/api/simulate_capacity`.

Este diseño es coherente con el enfoque del Plan Nacional de Disminución de Tiempos de Espera: la lista es un proceso dinámico; la gestión debe combinar priorización, mejor uso de capacidad, contactabilidad, transparencia, salud digital e interoperabilidad.

## Estructura

```text
healthos_dm2_prioriza_fullstack/
├── docker-compose.yml
├── requirements.txt
├── requirements-ml.txt
├── requirements-db.txt
├── config/
│   ├── data_taxonomy.yaml
│   └── public_source_allowlist.json
├── docs/
├── src/
│   ├── backend/
│   │   ├── api_gateway.py
│   │   ├── prioritization_engine.py
│   │   ├── repository.py
│   │   ├── schemas.py
│   │   ├── ai_models/foot_vision.py
│   │   ├── chatbots/public_foot_rag.py
│   │   ├── chatbots/local_chat_safe.py
│   │   ├── integrations/fhir_tei_mapping.py
│   │   ├── integrations/rayen_bridge.py
│   │   └── security/
│   ├── data/
│   │   ├── generate_synthetic_minsal_dataset.py
│   │   └── output/
│   └── frontend/
│       └── src/
│           ├── App.js
│           └── styles/Glassmorphism.css
└── tests/
```

## Arquitectura de microservicios

```text
React / Crystal Glass UI :5173
             │
             ▼
       API Gateway :8000
       JWT + CORS + headers
       ┌──────────┼─────────────┐
       ▼          ▼             ▼
Priorización   Pie DM2 IA    Chat local seguro
  :8001          :8002           :8003
       │                          │
       ▼                          ▼
Dataset sintético          Repositorio local read-only
       │
       ├─ Bridge Rayen local DESHABILITADO por defecto
       └─ Mapeo FHIR R4/TEI demostrativo

Chat público :8004 vive en una red interna separada y no monta el dataset.
```

Las redes `healthos_internal` y `healthos_public_chat` son internas. El chatbot público corre separado y no monta el dataset; solo el gateway y el frontend tienen borde de red. PostgreSQL queda como perfil opcional `persistent` para una evolución posterior.

## Inicio rápido

### 1. Generar o regenerar 10.000 pacientes sintéticos

```bash
python src/data/generate_synthetic_minsal_dataset.py \
  --count 10000 \
  --output src/data/output/patients_dm2_synthetic.csv
```

El repositorio ya incluye una corrida reproducible con semilla fija. Todos los identificadores comienzan con `SYN-` para que no puedan confundirse con RUT reales.

### 2. Configurar

```bash
cp .env.example .env
```

Cambie `HEALTHOS_JWT_SECRET` antes de ejecutar fuera de un computador de demostración.

### 3. Ejecutar con Docker

```bash
docker compose up --build
```

- Frontend: `http://localhost:5173`
- Gateway / OpenAPI: `http://localhost:8000/docs`

### 4. Desarrollo sin Docker

Terminal 1:

```bash
pip install -r requirements.txt
uvicorn src.backend.prioritization_engine:app --port 8001 --reload
```

Terminal 2:

```bash
uvicorn src.backend.ai_models.foot_vision:app --port 8002 --reload
```

Terminal 3:

```bash
uvicorn src.backend.chatbots.local_chat_safe:app --port 8003 --reload
```

Terminal 4:

```bash
uvicorn src.backend.chatbots.public_foot_chat_app:app --port 8004 --reload
```

Terminal 5:

```bash
uvicorn src.backend.api_gateway:app --port 8000 --reload
```

Terminal 6:

```bash
cd src/frontend
npm install
npm run dev
```

## Dataset sintético y taxonomía

Campos exigidos:

- `RUT_Sintetico`
- `Edad`
- `Fecha_Inscripcion_Lista`
- `Synthetic_HbA1c`
- `Comorbilidades_Sinteticas`
- `Ultima_Visita_Hospital_Sintetica`
- `Institucion_ID`
- `Ubicacion_Sintetica_PieDiabetico_ImageURL`

Extensiones necesarias para el MVP:

- `Estrato_ECICEP_Sintetico` (`G1`, `G2`, `G3`)
- `Riesgo_Pie_Diabetico_Sintetico`
- `Wagner_Sintetico`
- `Riesgo_Hipoglicemia_Sintetico`
- `No_Show_Risk_Sintetico`
- `Ruta_Sugerida`
- `Data_Classification`

El estrato ECICEP sintético usa el conteo de condiciones crónicas: DM2 como condición base, `G1` con una condición, `G2` con 2 a 4 y `G3` con 5 o más. La coherencia sintética se produce mediante distribuciones correlacionadas: edad, HbA1c, comorbilidad renal, neuropatía y control metabólico influyen probabilísticamente en riesgo de pie diabético y etapa Wagner. **Estas relaciones no son un modelo clínico validado.**

## Motor de priorización

### Score de antigüedad

```python
waiting_score = log(1 + dias_en_lista) / log(1 + 730)
```

El escalamiento logarítmico protege casos antiguos sin permitir que la antigüedad anule por completo el riesgo clínico.

### Score clínico sintético

Combina:

- HbA1c sintética.
- Comorbilidades ponderadas y estrato ECICEP sintético.
- Riesgo sintético de pie diabético y Wagner.
- Riesgo sintético de hipoglicemia.
- Tiempo desde última visita.
- Edad como factor secundario de vulnerabilidad; nunca reduce prioridad.

### Score total

```python
total = 0.72 * clinical_risk + 0.28 * waiting_score
```

Los pesos son parámetros auditables. El endpoint exige que el riesgo pese más que la antigüedad y que ambos sumen `1.0`.

### Salida explicable

Cada fila devuelve:

- posición anterior;
- nueva posición;
- movimiento;
- score clínico;
- score de antigüedad;
- score total;
- banda de prioridad;
- códigos de razón visibles;
- bandera de revisión profesional inmediata.

No se muestra ni se solicita “chain-of-thought”. La explicación se construye con factores observables y reglas auditables.

## Simulación de capacidad

`POST /api/simulate_capacity` recibe:

```json
{
  "current_doctors": 5,
  "additional_doctors": 3,
  "appointments_per_doctor_per_day": 12,
  "workdays_per_week": 5,
  "weekly_new_entries": 100
}
```

El cálculo muestra escenario base y escenario con capacidad adicional. Si las entradas semanales superan o igualan la capacidad, la cola se declara `creciente/sin equilibrio`. Es una simulación operacional simplificada, no un pronóstico oficial.

## Pie diabético IA

`src/backend/ai_models/foot_vision.py` contiene dos modos:

1. **`synthetic-deterministic`**, activo por defecto. Usa hash de una URL `synthetic://` para producir una salida reproducible sin descargar imágenes.
2. **`torchscript-local`**, activable al proporcionar pesos locales revisados en `HEALTHOS_MODEL_PATH` e instalar `requirements-ml.txt`.

La API devuelve etapa Wagner sintética, probabilidad, señal de infección, sugerencia de priorización y descargo de responsabilidad.

No se implementa carga remota de URLs para evitar SSRF. En una evolución real, las imágenes deben ingresar por un servicio de medios local con:

- validación de MIME y firma del archivo;
- límite de tamaño y resolución;
- eliminación de EXIF;
- antivirus / sandbox;
- almacenamiento cifrado temporal;
- retención limitada;
- consentimiento y propósito documentado.

## Dos chatbots con separación estricta

### 1. Chatbot público de pie diabético

Se ejecuta como proceso y red Docker separados (`public-foot-chat:8004`) y no monta el dataset.


Endpoint: `POST /api/chat/public-foot`

- Solo educación general y señales de alerta.
- RAG sintético reemplazable por documentos públicos revisados.
- No recibe `patient_synthetic_id` ni `institution_id`.
- No tiene acceso al repositorio de pacientes.
- Indica derivación profesional y no diagnostica.

### 2. Chatbot local de lista de espera

Endpoint: `POST /api/chat/local-list`

- Requiere JWT y rol.
- Jefatura puede ver agregados nacionales sintéticos.
- Médico y enfermería quedan limitados al `institution_id` del token.
- No existe text-to-SQL.
- Cada intención se traduce a una función allowlisted del repositorio.
- Llama.cpp es opcional y solo puede **reformular una respuesta factual ya calculada**; nunca recibe herramientas ni acceso a la base.

Consultas admitidas:

- resumen de lista;
- cantidad de prioridad alta;
- explicación de un paciente sintético;
- cantidad de pacientes por encima de otro;
- desglose agregado por institución.

## Integración con Rayen en CESFAM

El archivo `integrations/rayen_bridge.py` define un contrato local, pero queda deshabilitado por defecto:

```env
HEALTHOS_RAYEN_BRIDGE_ENABLED=false
```

HealthOS **no presume ni inventa una API pública de Rayen**. La integración real debe realizarse mediante un bridge on-premise autorizado por el Servicio de Salud, municipio y proveedor, con especificación contractual, mapeo de campos, autenticación mutua, auditoría, pruebas de carga, evaluación de privacidad y plan de reversibilidad.

El flujo recomendado es:

```text
Rayen en CESFAM
   │ exportación/evento autorizado
   ▼
Bridge local del Servicio de Salud
   │ normalización + validación + mínimo necesario
   ▼
Contrato FHIR/TEI o esquema HealthOS
   │
   ▼
HealthOS dentro de la red autorizada
```

El navegador nunca debe conectarse directamente a Rayen y no almacena credenciales del sistema APS.

## Interoperabilidad MINSAL

`integrations/fhir_tei_mapping.py` entrega un ejemplo **FHIR R4-shaped** con `Patient` y `ServiceRequest`, marcado explícitamente como sintético. No afirma conformidad oficial. Para una integración real se debe validar contra la Guía de Implementación de Tiempos de Espera Interoperable de MINSAL y sus perfiles/eventos vigentes.

Fuentes públicas permitidas por configuración:

- `minsal.cl`
- `interoperabilidad.minsal.cl`
- `deis.minsal.cl`

La allowlist no autoriza scraping, ni envío de información clínica, ni eludir términos de uso.

## Jerarquía de datos

| Nivel | Ejemplos | Acceso |
|---|---|---|
| `PUBLIC` | guías y estadísticas agregadas | los tres roles |
| `SYNTHETIC_OPERATIONAL` | lista y pacientes ficticios | los tres roles |
| `LOCAL_CLINICAL` | futura información real autorizada | médico/enfermería, mínimo privilegio |
| `RESTRICTED_SECURITY` | secretos, RBAC, bitácoras | administración de seguridad |

Una transición a datos reales requiere separación física/lógica adicional, DPIA, gestión de consentimiento y cumplimiento normativo aplicable.

## RBAC

### Jefatura DM2

- analítica agregada nacional;
- comparación entre instituciones;
- simulación de capacidad;
- parámetros y políticas de priorización;
- no modifica decisiones clínicas individuales desde el tablero agregado.

### Médico

- agenda y pacientes de su institución/alcance;
- revisión de explicación del score;
- clasificación asistiva de pie diabético;
- confirmación, rechazo o derivación clínica.

### Enfermería

- tareas asignadas;
- curaciones, educación, contacto y seguimiento;
- actualización de síntomas y escalamiento;
- sin acceso a configuración nacional del algoritmo.

## Threat Model resumido — STRIDE

| Amenaza | Escenario | Controles incluidos | Pendiente para producción |
|---|---|---|---|
| Spoofing | uso de token ajeno | JWT con audiencia, vencimiento y RBAC | IdP institucional, MFA, mTLS |
| Tampering | alterar score o dataset | contenedores read-only, auditoría, pesos explícitos | firma de modelos/datos, WORM logs |
| Repudiation | negar una acción | `audit_id`, trazabilidad por usuario | SIEM, sellado temporal, no repudio |
| Information disclosure | fuga por chatbot/log | separación de bots, redacción, pseudonimización | DLP, HSM/KMS, revisión de retención |
| Denial of service | abuso de API | límites de payload y rate limit local | gateway enterprise, Redis, circuit breakers |
| Elevation of privilege | enfermería consulta nacional | alcance desde JWT e institución | ABAC, revisión periódica de permisos |

### Amenazas específicas de IA/RAG

| Riesgo | Mitigación aplicada |
|---|---|
| Prompt injection | patrones de bloqueo, sistema sin herramientas abiertas, intents allowlisted |
| SQL injection por LLM | no existe text-to-SQL; solo repositorio tipado/read-only |
| Exfiltración por contexto | bot público sin contexto; bot local recibe solo resultado mínimo |
| SSRF por URL de imagen | solo `synthetic://` o dominio interno sintético; no descarga externa |
| Model poisoning | no entrenamiento en línea; pesos locales versionados |
| Hallucination | respuestas factuales calculadas antes del LLM; evidencia visible |
| Fuga en logs | redacción de secretos/RUT y hash de identificadores |
| Supply-chain | versiones fijadas, imágenes pequeñas, usuario no root | SBOM, firma Cosign y scanning CI pendientes |

## Seguridad de despliegue local/desktop

Para un modo desktop se recomienda empaquetar frontend + gateway en Tauri/Electron con sidecars locales. El perfil seguro debe:

- escuchar solo en `127.0.0.1`;
- bloquear salida a internet salvo allowlist explícita;
- cifrar el volumen local;
- usar almacenamiento de secretos del sistema operativo;
- desactivar DevTools en producción;
- verificar firma de actualizaciones;
- sincronizar únicamente mediante bridge institucional autenticado;
- borrar temporales y caché clínica.

## Fuentes conceptuales públicas

- MINSAL, *Plan Nacional de Disminución de Tiempos de Espera 2022–2026*.
- MINSAL, Guía de Implementación *Tiempos de Espera Interoperable*.
- MINSAL, Guía de Estándares de Información en Salud / FHIR.
- MINSAL, Marco Operativo de la Estrategia de Cuidado Integral Centrado en las Personas (ECICEP).

Las cifras del dataset y del frontend son sintéticas; no reproducen registros individuales ni resultados oficiales.
