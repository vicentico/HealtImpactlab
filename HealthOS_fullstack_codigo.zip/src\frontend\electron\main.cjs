const { app, BrowserWindow, dialog } = require("electron");
const { spawn } = require("child_process");
const http = require("http");
const path = require("path");

const PORT = 8765;
let backendProcess;

function waitForBackend(attempts = 80) {
  return new Promise((resolve, reject) => {
    const check = () => {
      const request = http.get(`http://127.0.0.1:${PORT}/health`, (response) => {
        response.resume();
        if (response.statusCode === 200) resolve();
        else retry();
      });
      request.on("error", retry);
      request.setTimeout(600, () => request.destroy());
    };
    const retry = () => attempts-- > 0 ? setTimeout(check, 250) : reject(new Error("El motor local no inició a tiempo."));
    check();
  });
}

function startBackend() {
  const packaged = app.isPackaged;
  const executable = packaged
    ? path.join(process.resourcesPath, "backend", "healthos-api.exe")
    : "python";
  const args = packaged
    ? []
    : [path.resolve(__dirname, "..", "..", "backend", "desktop_server.py")];
  const env = {
    ...process.env,
    HEALTHOS_PORT: String(PORT),
    HEALTHOS_FRONTEND_DIST: packaged
      ? path.join(process.resourcesPath, "web")
      : path.resolve(__dirname, "..", "dist"),
    HEALTHOS_DATASET_PATH: packaged
      ? path.join(process.resourcesPath, "data", "patients_dm2_synthetic.csv")
      : path.resolve(__dirname, "..", "..", "data", "output", "patients_dm2_synthetic.csv"),
  };
  backendProcess = spawn(executable, args, { env, windowsHide: true, stdio: "ignore" });
}

async function createWindow() {
  startBackend();
  try {
    await waitForBackend();
  } catch (error) {
    dialog.showErrorBox("HealthOS", error.message);
    app.quit();
    return;
  }
  const window = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 390,
    minHeight: 720,
    backgroundColor: "#03111f",
    title: "HealthOS DM2 Prioriza",
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  await window.loadURL(`http://127.0.0.1:${PORT}`);
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => app.quit());
app.on("before-quit", () => {
  if (backendProcess && !backendProcess.killed) backendProcess.kill();
});
