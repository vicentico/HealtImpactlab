"""Separated chatbot security domains."""
