from datetime import date, timedelta

from src.backend.prioritization_engine import prioritize_patients
from src.backend.schemas import PatientRecord


def patient(identifier: str, hba1c: float, days: int, wagner: int = 0, foot_risk: float = 0.1):
    return PatientRecord(
        rut_sintetico=identifier,
        nombre_sintetico="Paciente Sintético",
        edad=60,
        sexo_sintetico="F",
        fecha_inscripcion_lista=date.today() - timedelta(days=days),
        synthetic_hba1c=hba1c,
        comorbilidades_sinteticas=["Hipertensión"],
        estrato_ecicep_sintetico="G2",
        ultima_visita_hospital_sintetica=date.today() - timedelta(days=90),
        institucion_id="INST-001",
        institucion_nombre="Hospital Sintético",
        region="Metropolitana",
        ubicacion_sintetica_pie_diabetico_imageurl=f"synthetic://healthos/{identifier}",
        riesgo_pie_diabetico_sintetico=foot_risk,
        wagner_sintetico=wagner,
        riesgo_hipoglicemia_sintetico=0.1,
        no_show_risk_sintetico=0.2,
        route_sugerida="Diabetología",
    )


def test_high_risk_can_move_above_older_low_risk_patient():
    older = patient("SYN-90000001-5", 7.2, 600)
    urgent = patient("SYN-90000002-3", 11.5, 90, wagner=3, foot_risk=0.9)
    result = prioritize_patients([older, urgent])
    assert result[0].patient.rut_sintetico == urgent.rut_sintetico
    assert len(result) == 2


def test_prioritization_does_not_change_queue_size():
    patients = [
        patient("SYN-90000003-1", 7.5, 100),
        patient("SYN-90000004-K", 9.5, 200),
        patient("SYN-90000005-8", 8.2, 300),
    ]
    assert len(prioritize_patients(patients)) == len(patients)
