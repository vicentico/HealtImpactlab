from __future__ import annotations

import os
from typing import Annotated, Any

import httpx
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse

from src.backend.config import get_settings
from src.backend.schemas import Role
from src.backend.security.auth import CurrentUser, create_demo_token, get_current_user
from src.backend.security.middleware import LocalRateLimitMiddleware, SecurityHeadersMiddleware

settings = get_settings()
PRIORITIZATION_URL = os.getenv("PRIORITIZATION_URL", "http://127.0.0.1:8001")
FOOT_VISION_URL = os.getenv("FOOT_VISION_URL", "http://127.0.0.1:8002")
LOCAL_CHAT_URL = os.getenv("LOCAL_CHAT_URL", "http://127.0.0.1:8003")
PUBLIC_CHAT_URL = os.getenv("PUBLIC_CHAT_URL", "http://127.0.0.1:8004")

app = FastAPI(
    title="HealthOS DM2 Prioriza - API Gateway",
    version="0.1.0",
    default_response_class=ORJSONResponse,
)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(LocalRateLimitMiddleware, requests_per_minute=200)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origin_list,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "gateway", "platform": "HealthOS DM2 Prioriza"}


@app.post("/api/auth/demo-token")
def demo_token(role: Role, institution_id: str | None = "INST-001") -> dict[str, str]:
    """Development-only. Remove this route before any non-demo deployment."""
    if settings.env not in {"development", "demo", "test"}:
        raise HTTPException(status_code=404, detail="No disponible")
    subject = f"demo-{role.value}"
    return {
        "access_token": create_demo_token(subject, role, institution_id),
        "token_type": "bearer",
        "role": role.value,
    }


async def proxy_json(
    request: Request,
    target_base: str,
    target_path: str,
    user: CurrentUser,
) -> Any:
    body = await request.json()
    token = request.headers.get("authorization", "")
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(
                f"{target_base.rstrip('/')}{target_path}",
                json=body,
                headers={"Authorization": token, "X-HealthOS-User": user.subject},
            )
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail="Microservicio local no disponible") from exc
    try:
        payload = response.json()
    except ValueError:
        payload = {"detail": "Respuesta inválida del microservicio"}
    if response.status_code >= 400:
        raise HTTPException(status_code=response.status_code, detail=payload.get("detail", payload))
    return payload


@app.post("/api/prioritize")
async def prioritize(
    request: Request,
    user: Annotated[CurrentUser, Depends(get_current_user)],
):
    return await proxy_json(request, PRIORITIZATION_URL, "/api/prioritize", user)


@app.post("/api/simulate_capacity")
async def simulate_capacity(
    request: Request,
    user: Annotated[CurrentUser, Depends(get_current_user)],
):
    return await proxy_json(request, PRIORITIZATION_URL, "/api/simulate_capacity", user)


@app.post("/api/diabetic_foot/classify")
async def classify_foot(
    request: Request,
    user: Annotated[CurrentUser, Depends(get_current_user)],
):
    return await proxy_json(request, FOOT_VISION_URL, "/api/diabetic_foot/classify", user)


@app.post("/api/chat/local-list")
async def local_chat(
    request: Request,
    user: Annotated[CurrentUser, Depends(get_current_user)],
):
    return await proxy_json(request, LOCAL_CHAT_URL, "/api/chat/local-list", user)


@app.post("/api/chat/public-foot")
async def public_chat(request: Request):
    # Public bot intentionally receives no bearer token or patient scope.
    body = await request.json()
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{PUBLIC_CHAT_URL}/api/chat/public-foot", json=body)
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail="Chatbot público local no disponible") from exc
    payload = response.json()
    if response.status_code >= 400:
        raise HTTPException(status_code=response.status_code, detail=payload.get("detail", payload))
    return payload
