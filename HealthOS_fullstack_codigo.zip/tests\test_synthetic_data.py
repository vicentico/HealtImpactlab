from pathlib import Path

from src.data.generate_synthetic_minsal_dataset import generate_dataset


def test_generator_creates_only_prefixed_ids(tmp_path: Path):
    output = tmp_path / "patients.csv"
    frame = generate_dataset(100, output)
    assert len(frame) == 100
    assert frame["RUT_Sintetico"].str.startswith("SYN-").all()
    assert frame["RUT_Sintetico"].is_unique
    assert frame["Synthetic_HbA1c"].between(4.0, 20.0).all()
