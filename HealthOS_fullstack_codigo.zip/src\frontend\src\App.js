import React, { useEffect, useMemo, useState } from "react";
import "./styles/Glassmorphism.css";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "";

const roleLabels = {
  jefatura_dm2: "Jefatura DM2",
  medico: "Médico",
  enfermeria: "Enfermería",
};

const navItems = [
  ["Resumen nacional", "⌂"],
  ["Lista de espera", "≋"],
  ["Priorización", "◎"],
  ["Pie diabético IA", "♙"],
  ["Chatbot clínico", "◌"],
  ["Ciberseguridad", "◇"],
  ["Usuarios y roles", "♧"],
  ["Configuración", "⚙"],
];

function formatNumber(value) {
  return new Intl.NumberFormat("es-CL").format(value ?? 0);
}

function priorityClass(priority) {
  return `priority priority-${String(priority || "programada")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replaceAll(" ", "-")}`;
}

async function apiFetch(path, { token, method = "POST", body } = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.detail || "Error de API local");
  return payload;
}

function BrandMark() {
  return (
    <div className="brand">
      <img className="brand-logo" src="/healthos-logo.png" alt="Logo de HealthOS" />
      <div>
        <strong>HealthOS</strong>
        <span>DM2 Prioriza</span>
        <small>Orquestación inteligente de espera</small>
      </div>
    </div>
  );
}

function Sidebar({ role, setRole, activeView, setActiveView }) {
  return (
    <aside className="sidebar glass-panel">
      <BrandMark />
      <div className="role-switcher glass-inset">
        <p className="eyebrow">ROL ACTIVO</p>
        {Object.entries(roleLabels).map(([value, label]) => (
          <button
            type="button"
            className={role === value ? "role-button active" : "role-button"}
            key={value}
            onClick={() => setRole(value)}
          >
            <span>{value === "jefatura_dm2" ? "♛" : value === "medico" ? "♧" : "♡"}</span>
            {label}
            <i />
          </button>
        ))}
      </div>
      <p className="eyebrow nav-label">NAVEGACIÓN</p>
      <nav>
        {navItems.map(([label, icon]) => (
          <button
            type="button"
            key={label}
            onClick={() => setActiveView(label)}
            className={activeView === label ? "nav-button active" : "nav-button"}
          >
            <span>{icon}</span>{label}
          </button>
        ))}
      </nav>
      <div className="privacy-badge glass-inset">
        <span className="status-dot" />
        <div><strong>Modo sintético local</strong><small>Sin datos privados reales</small></div>
      </div>
      <div className="profile-card glass-inset">
        <div className="avatar">HS</div>
        <div><strong>Health Solutions</strong><small>{roleLabels[role]}</small></div>
        <span>›</span>
      </div>
    </aside>
  );
}

function MetricCard({ icon, label, value, detail, tone = "cyan" }) {
  return (
    <article className={`metric-card glass-panel tone-${tone}`}>
      <div className="metric-head"><span>{icon}</span><small>{label}</small></div>
      <strong>{value}</strong>
      <p>{detail}</p>
      <div className="sparkline"><i /><i /><i /><i /><i /></div>
    </article>
  );
}

function ChileCoverage({ summary }) {
  const regions = ["Norte", "Centro", "Sur", "Austral"];
  return (
    <article className="coverage glass-panel">
      <header><strong>Cobertura nacional sintética</strong><span>15 / 15 nodos</span></header>
      <div className="coverage-body">
        <div className="chile-map" aria-label="Representación abstracta de Chile">
          {Array.from({ length: 17 }).map((_, index) => <i key={index} style={{ "--i": index }} />)}
        </div>
        <div className="region-list">
          {regions.map((region, index) => (
            <div key={region}><span><strong>{region}</strong><small>{3 + index} instituciones</small></span><b /></div>
          ))}
        </div>
      </div>
      <small>Fuente de demo: dataset sintético inspirado en taxonomías públicas.</small>
    </article>
  );
}

function WaitlistTable({ patients, selectedId, onSelect }) {
  const [query, setQuery] = useState("");
  const [priority, setPriority] = useState("Todas");
  const visible = patients.filter((item) => {
    const haystack = `${item.patient.nombre_sintetico} ${item.patient.rut_sintetico} ${item.patient.institucion_nombre}`.toLowerCase();
    return haystack.includes(query.toLowerCase()) && (priority === "Todas" || item.priority_band === priority);
  });
  const exportCsv = () => {
    const header = ["ID sintético", "Paciente", "Institución", "Prioridad", "Posición", "Score"];
    const rows = visible.map((item) => [item.patient.rut_sintetico, item.patient.nombre_sintetico, item.patient.institucion_nombre, item.priority_band, item.new_position, item.total_score]);
    const csv = [header, ...rows].map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8" }));
    link.download = "healthos-lista-priorizada-demo.csv";
    link.click();
    URL.revokeObjectURL(link.href);
  };
  return (
    <article className="waitlist glass-panel">
      <header className="panel-header">
        <div><h2>Lista de espera reestructurada</h2><p>Riesgo clínico + antigüedad, con trazabilidad de cada movimiento.</p></div>
        <div className="button-row waitlist-controls">
          <input aria-label="Buscar paciente" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar ID, paciente u hospital" />
          <select aria-label="Filtrar por prioridad" value={priority} onChange={(event) => setPriority(event.target.value)}>
            {["Todas", "Revisión inmediata", "Muy alta", "Alta", "Media", "Programada"].map((item) => <option key={item}>{item}</option>)}
          </select>
          <button type="button" onClick={exportCsv}>⇩ Exportar</button>
        </div>
      </header>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Paciente</th><th>Institución / ruta</th><th>Prioridad</th><th>Anterior</th><th>Nueva</th><th>Movimiento</th><th>Score</th><th>Estado</th></tr></thead>
          <tbody>
            {visible.slice(0, 12).map((item) => (
              <tr key={item.patient.rut_sintetico} className={selectedId === item.patient.rut_sintetico ? "selected" : ""} onClick={() => onSelect(item.patient.rut_sintetico)}>
                <td><div className="patient-cell"><span className="radio-dot" /><div><strong>{item.patient.nombre_sintetico}</strong><small>{item.patient.rut_sintetico} · {item.patient.edad} años</small></div></div></td>
                <td><strong>{item.patient.institucion_nombre}</strong><small>{item.patient.route_sugerida}</small></td>
                <td><span className={priorityClass(item.priority_band)}>{item.priority_band}</span></td>
                <td>{formatNumber(item.previous_position)}</td>
                <td><strong>{formatNumber(item.new_position)}</strong></td>
                <td className={item.movement >= 0 ? "movement up" : "movement down"}>{item.movement >= 0 ? "↑" : "↓"} {formatNumber(Math.abs(item.movement))}</td>
                <td>{item.total_score.toFixed(2)}</td>
                <td><span className="status-dot" />Propuesto</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <footer>Mostrando {Math.min(12, visible.length)} de {formatNumber(visible.length)} resultados · la cola total no cambia al priorizar.</footer>
    </article>
  );
}

function PriorityExplanation({ selected }) {
  if (!selected) return <article className="glass-panel empty-card">Seleccione un paciente sintético.</article>;
  const p = selected.patient;
  return (
    <article className="explanation glass-panel">
      <header><div className="avatar">{p.nombre_sintetico.split(" ").slice(0, 2).map((x) => x[0]).join("")}</div><div><h3>{p.nombre_sintetico}</h3><small>{p.rut_sintetico} · {p.edad} años</small></div><div className="score-box"><strong>{selected.total_score.toFixed(2)}</strong><small>riesgo</small></div></header>
      <div className="factor-grid">
        <div><span>HbA1c</span><strong>{p.synthetic_hba1c.toFixed(1)}%</strong></div>
        <div><span>Wagner sintético</span><strong>{p.wagner_sintetico}</strong></div><div><span>ECICEP</span><strong>{p.estrato_ecicep_sintetico}</strong></div>
        <div><span>Riesgo pie</span><strong>{p.riesgo_pie_diabetico_sintetico.toFixed(2)}</strong></div>
        <div><span>Antigüedad</span><strong>{selected.waiting_score.toFixed(2)}</strong></div>
      </div>
      <h4>Explicación auditable</h4>
      <ul>{selected.explanation.slice(0, 4).map((reason) => <li key={reason}>{reason}</li>)}</ul>
      <div className="action-banner">Acción sugerida: revisión profesional según ruta {p.route_sugerida}.</div>
    </article>
  );
}

function FootVisionCard({ selected, token }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const classify = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      const data = await apiFetch("/api/diabetic_foot/classify", {
        token,
        body: {
          synthetic_image_url: selected.patient.ubicacion_sintetica_pie_diabetico_imageurl,
          patient_synthetic_id: selected.patient.rut_sintetico,
        },
      });
      setResult(data);
    } finally { setLoading(false); }
  };
  return (
    <article className="foot-ai glass-panel">
      <header><div><h3>Pie diabético IA</h3><small>Visión artificial + wrapper CNN local</small></div><span className="ai-tag">IA asistiva</span></header>
      <div className="foot-ai-body">
        <div className="synthetic-foot" aria-label="Marcador abstracto; no es una imagen clínica"><span>PIE</span><i /></div>
        <div>{result ? <><small>Etapa sugerida</small><strong>Wagner {result.synthetic_stage}</strong><p>Confianza {result.synthetic_probability}</p></> : <><strong>Sin analizar</strong><p>Solo URL sintética interna.</p></>}</div>
      </div>
      <button className="primary-button" onClick={classify} disabled={!selected || loading}>{loading ? "Analizando…" : "Ejecutar inferencia sintética"}</button>
      {result && <small className="disclaimer">{result.disclaimer}</small>}
    </article>
  );
}

function ChatPanel({ title, mode, role, token, selected }) {
  const [messages, setMessages] = useState([{ from: "bot", text: mode === "public" ? "Pregunta por prevención o señales de alerta del pie diabético. No ingreses datos personales." : "Consulta la lista sintética dentro de tu alcance autorizado." }]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const send = async () => {
    const text = input.trim();
    if (!text) return;
    setInput(""); setBusy(true); setMessages((prev) => [...prev, { from: "user", text }]);
    try {
      const body = mode === "public"
        ? { message: text, role }
        : { message: text, role, institution_id: role === "jefatura_dm2" ? null : "INST-001", patient_synthetic_id: selected?.patient.rut_sintetico || null };
      const data = await apiFetch(mode === "public" ? "/api/chat/public-foot" : "/api/chat/local-list", { token: mode === "public" ? null : token, body });
      setMessages((prev) => [...prev, { from: "bot", text: data.answer }]);
    } catch (error) {
      setMessages((prev) => [...prev, { from: "bot", text: `No fue posible consultar el servicio local: ${error.message}` }]);
    } finally { setBusy(false); }
  };
  return (
    <article className="chat-panel glass-panel">
      <header><div><h3>{title}</h3><small>{mode === "public" ? "Dominio público aislado" : "Base local + APIs allowlisted"}</small></div><span className="online-dot">En línea</span></header>
      <div className="chat-messages">{messages.slice(-5).map((message, index) => <p key={`${message.from}-${index}`} className={message.from}>{message.text}</p>)}</div>
      <div className="chat-input"><input value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => event.key === "Enter" && send()} placeholder="Escribe una consulta segura…" maxLength={700} /><button onClick={send} disabled={busy}>➤</button></div>
    </article>
  );
}

function CapacitySimulator({ token }) {
  const [doctors, setDoctors] = useState(2);
  const [result, setResult] = useState(null);
  const run = async () => {
    const data = await apiFetch("/api/simulate_capacity", {
      token,
      body: { current_doctors: 5, additional_doctors: Number(doctors), appointments_per_doctor_per_day: 12, workdays_per_week: 5, weekly_new_entries: 100 },
    });
    setResult(data);
  };
  return (
    <article className="capacity glass-panel">
      <header><h3>Simulación de capacidad</h3><span>What-if</span></header>
      <p>Agregar profesionales modifica el tiempo global estimado, no el criterio de orden.</p>
      <label>+{doctors} médicos<input type="range" min="0" max="15" value={doctors} onChange={(event) => setDoctors(event.target.value)} /></label>
      <button className="primary-button" onClick={run}>Recalcular escenario</button>
      {result && <><div className="capacity-result"><span>Antes <strong>{String(result.estimated_global_wait_days_before)} días</strong></span><b>→</b><span>Después <strong>{String(result.estimated_global_wait_days_after)} días</strong></span></div><p className="capacity-impact">Capacidad liberada: <strong>{formatNumber(result.recoverable_slots_per_week || 0)} cupos/semana</strong> · reducción estimada {result.estimated_reduction_percent}%</p></>}
    </article>
  );
}

function NurseWorkflow({ patients }) {
  const columns = ["Curación / Pie", "Educación", "Llamado", "Exámenes", "Escalar a médico"];
  return (
    <section className="workflow glass-panel">
      <header className="panel-header"><div><h2>Workflow de tratamiento</h2><p>Tareas alineadas con la priorización médica.</p></div></header>
      <div className="kanban">{columns.map((column, columnIndex) => <div className="kanban-column" key={column}><header><strong>{column}</strong><span>{columnIndex + 3}</span></header>{patients.slice(columnIndex * 2, columnIndex * 2 + 3).map((item, index) => <article key={item.patient.rut_sintetico}><small>{`0${8 + index}:00`}</small><strong>{item.patient.nombre_sintetico}</strong><span className={priorityClass(item.priority_band)}>{item.priority_band}</span><button>Confirmar tarea</button></article>)}</div>)}</div>
    </section>
  );
}

function DoctorAgenda({ patients, onSelect }) {
  return (
    <section className="workflow glass-panel">
      <header className="panel-header"><div><h2>Agenda priorizada del médico</h2><p>Riesgo DM2, última visita, complicaciones y capacidad disponible.</p></div><button>Auto-priorizar</button></header>
      <div className="agenda-list">{patients.slice(0, 10).map((item, index) => <button key={item.patient.rut_sintetico} onClick={() => onSelect(item.patient.rut_sintetico)}><time>{String(8 + Math.floor(index / 2)).padStart(2, "0")}:{index % 2 ? "30" : "00"}</time><span><strong>{item.patient.nombre_sintetico}</strong><small>{item.patient.route_sugerida} · {item.patient.institucion_nombre}</small></span><span className={priorityClass(item.priority_band)}>{item.priority_band}</span><b>{item.total_score.toFixed(2)}</b></button>)}</div>
    </section>
  );
}

export default function App() {
  const [role, setRole] = useState("jefatura_dm2");
  const [activeView, setActiveView] = useState("Resumen nacional");
  const [token, setToken] = useState("");
  const [patients, setPatients] = useState([]);
  const [metrics, setMetrics] = useState({});
  const [selectedId, setSelectedId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        setError("");
        const tokenResponse = await apiFetch(`/api/auth/demo-token?role=${role}&institution_id=INST-001`, { method: "POST" });
        if (cancelled) return;
        setToken(tokenResponse.access_token);
        const data = await apiFetch("/api/prioritize", { token: tokenResponse.access_token, body: { limit: 250, risk_weight: 0.72, waiting_weight: 0.28, include_explanations: true } });
        if (cancelled) return;
        setPatients(data.patients);
        setMetrics(data.metrics);
        setSelectedId(data.patients[0]?.patient.rut_sintetico || null);
      } catch (loadError) { if (!cancelled) setError(loadError.message); }
    }
    load();
    return () => { cancelled = true; };
  }, [role]);

  const selected = useMemo(() => patients.find((item) => item.patient.rut_sintetico === selectedId), [patients, selectedId]);
  const highPriority = metrics.high_priority ?? patients.filter((item) => ["Revisión inmediata", "Muy alta", "Alta"].includes(item.priority_band)).length;

  const showRoleView = activeView === "Resumen nacional" || activeView === "Lista de espera" || activeView === "Priorización";

  return (
    <main className="app-shell">
      <div className="ambient ambient-a" /><div className="ambient ambient-b" />
      <Sidebar role={role} setRole={setRole} activeView={activeView} setActiveView={setActiveView} />
      <section className="workspace">
        <header className="topbar"><div><p className="eyebrow">HEALTHSOLUTIONS · CLAUDE IMPACT LAB 2026 · LONGEVIDAD / LÍNEA 2</p><h1>{activeView === "Pie diabético IA" ? "Clasificación asistiva de pie diabético" : role === "medico" ? "Agenda clínica priorizada" : role === "enfermeria" ? "Centro operativo de enfermería" : "Torre de control nacional DM2"}</h1><p>Transforma listas pasivas en rutas de atención priorizadas, explicables y accionables.</p></div><div className="top-actions"><button className="demo-pill">▣ Demo ejecutiva</button><button>◉ 100% sintético</button><button>⌘ Local-first</button></div></header>
        {error && <div className="error-banner">{error}. El motor local de HealthOS no está disponible.</div>}

        {activeView === "Pie diabético IA" ? (
          <div className="dedicated-grid"><FootVisionCard selected={selected} token={token} /><PriorityExplanation selected={selected} /><ChatPanel title="Chatbot público de pie diabético" mode="public" role={role} token={token} selected={selected} /><ChatPanel title="Copiloto local de lista" mode="local" role={role} token={token} selected={selected} /></div>
        ) : activeView === "Chatbot clínico" ? (
          <div className="dedicated-grid"><ChatPanel title="Chatbot público de pie diabético" mode="public" role={role} token={token} selected={selected} /><ChatPanel title="Chatbot local de lista de espera" mode="local" role={role} token={token} selected={selected} /><PriorityExplanation selected={selected} /><article className="glass-panel security-card"><h3>Separación de seguridad</h3><ul><li>El bot público nunca recibe IDs ni consulta pacientes.</li><li>El bot local no genera SQL y solo usa intenciones allowlisted.</li><li>RBAC limita hospital y función según el token local.</li><li>Los logs se redactan y pseudonimizan.</li></ul></article></div>
        ) : showRoleView ? (
          <>
            <section className="metrics-grid"><MetricCard icon="♙" label="Pacientes en espera" value={formatNumber(metrics.queue_size_unchanged || patients.length)} detail="Volumen sin reducción al reordenar" /><MetricCard icon="◷" label="Revisión inmediata" value={formatNumber(metrics.immediate_review || 0)} detail="Requieren revisión profesional" /><MetricCard icon="♨" label="Prioridad alta" value={formatNumber(highPriority)} detail="Riesgo + antigüedad" tone="amber" /><MetricCard icon="⌛" label="Mediana observada" value={`${metrics.median_waiting_days_observed || 0} días`} detail="Dato sintético de la cola" /><ChileCoverage /></section>
            {role === "jefatura_dm2" && <div className="dashboard-grid"><WaitlistTable patients={patients} selectedId={selectedId} onSelect={setSelectedId} /><aside className="right-rail"><PriorityExplanation selected={selected} /><CapacitySimulator token={token} /><FootVisionCard selected={selected} token={token} /></aside></div>}
            {role === "medico" && <div className="dashboard-grid"><DoctorAgenda patients={patients} onSelect={setSelectedId} /><aside className="right-rail"><PriorityExplanation selected={selected} /><FootVisionCard selected={selected} token={token} /><ChatPanel title="Copiloto clínico local" mode="local" role={role} token={token} selected={selected} /></aside></div>}
            {role === "enfermeria" && <div className="dashboard-grid"><NurseWorkflow patients={patients} /><aside className="right-rail"><PriorityExplanation selected={selected} /><ChatPanel title="Asistente local de coordinación" mode="local" role={role} token={token} selected={selected} /><article className="glass-panel checklist"><h3>Checklist de enfermería</h3>{["Curación / herida", "Control glicémico", "Educación", "Signos de infección", "Confirmación asistencia"].map((item, index) => <label key={item}><input type="checkbox" defaultChecked={index < 2} />{item}<span>{index < 2 ? "Realizada" : "Pendiente"}</span></label>)}</article></aside></div>}
          </>
        ) : (
          <div className="dedicated-grid"><article className="glass-panel security-card"><h2>{activeView}</h2><p>Módulo estructural incluido en el MVP. Los datos siguen la jerarquía PUBLIC → SYNTHETIC_OPERATIONAL → LOCAL_CLINICAL → RESTRICTED_SECURITY.</p><ul><li>Integración Rayen solo mediante bridge local autorizado.</li><li>Interoperabilidad preparada para mapeo FHIR/TEI.</li><li>Sin APIs no oficiales ni credenciales en el navegador.</li><li>Auditoría por rol, propósito y establecimiento.</li></ul></article><ChatPanel title="Chatbot local seguro" mode="local" role={role} token={token} selected={selected} /></div>
        )}
        <footer className="app-footer">HealthOS by HealthSolutions · Claude Impact Lab 2026 · Demo no clínica · Priorizar ≠ reducir lista</footer>
      </section>
    </main>
  );
}
