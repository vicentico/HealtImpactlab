"""Controlled integration adapters. No connector is enabled by default."""
