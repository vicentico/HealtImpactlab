from fastapi.testclient import TestClient

from src.backend.desktop_server import app


client = TestClient(app)


def demo_headers(role: str = "jefatura_dm2") -> dict[str, str]:
    response = client.post(f"/api/auth/demo-token?role={role}&institution_id=INST-001")
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_integrated_desktop_flow():
    headers = demo_headers()
    ranked = client.post(
        "/api/prioritize",
        headers=headers,
        json={"limit": 10, "risk_weight": 0.72, "waiting_weight": 0.28},
    )
    assert ranked.status_code == 200
    payload = ranked.json()
    assert len(payload["patients"]) == 10
    assert payload["metrics"]["queue_size_unchanged"] == 10_000

    capacity = client.post(
        "/api/simulate_capacity",
        headers=headers,
        json={"current_doctors": 5, "additional_doctors": 3},
    )
    assert capacity.status_code == 200
    assert capacity.json()["recoverable_slots_per_week"] == 180


def test_desktop_ui_is_served():
    response = client.get("/")
    assert response.status_code == 200
    assert "Torre de control hospitalaria DM2" in response.text


def test_epidemiology_model_is_balanced_and_transparent():
    response = client.get("/api/epidemiology/summary")
    assert response.status_code == 200
    payload = response.json()
    assert payload["classification"] == "SYNTHETIC_AGGREGATE_MODEL"
    assert payload["base_waitlist"]["total_records"] == 2_500_000
    assert payload["dm2_filtered_estimate"]["total_records"] == 300_000
    assert sum(row["consultation"] for row in payload["complications"]) == 270_000
    assert sum(row["surgery"] for row in payload["complications"]) == 30_000
    assert round(sum(row["percent_dm2"] for row in payload["complications"]), 1) == 100.0


def test_proprietary_license_is_exposed():
    response = client.get("/api/license")
    assert response.status_code == 200
    assert response.json()["owner"] == "Health Solutions"
