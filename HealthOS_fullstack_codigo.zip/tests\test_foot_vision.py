import pytest

from src.backend.ai_models.foot_vision import DiabeticFootVisionWrapper


def test_synthetic_inference_is_deterministic():
    model = DiabeticFootVisionWrapper()
    url = "synthetic://healthos/diabetic-foot/SYN-90000001-5"
    first = model.classify_url(url)
    second = model.classify_url(url)
    assert first == second
    assert 0 <= first.synthetic_stage <= 5


def test_external_urls_are_rejected():
    model = DiabeticFootVisionWrapper()
    with pytest.raises(ValueError):
        model.classify_url("https://example.com/patient.jpg")
