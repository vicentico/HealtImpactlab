# HealthOS — paquete de código fuente

Este paquete contiene el código necesario para modificar, probar y volver a compilar HealthOS.

## Aplicación actualmente utilizada

- Backend integrado: `src/backend/desktop_server.py`
- Lanzador de escritorio: `src/backend/desktop_launcher.py`
- Frontend integrado: `src/desktop_web/index.html`, `app.css` y `app.js`
- Modelo epidemiológico: `src/backend/epidemiology.py`
- Datos sintéticos: `src/data/output/patients_dm2_synthetic.csv`
- Generador de datos: `src/data/generate_synthetic_minsal_dataset.py`
- Web editable para pitch: `site/index.html`

## Desarrollo local

```powershell
python -m pip install -r requirements.txt
python -m src.backend.desktop_server
```

Luego abra `http://127.0.0.1:8765`.

## Pruebas

```powershell
python -m pytest -q
```

## Compilación de Windows

```powershell
powershell -ExecutionPolicy Bypass -File scripts/build_desktop.ps1
```

Los datos incluidos son sintéticos. No use esta demostración para decisiones clínicas reales.
