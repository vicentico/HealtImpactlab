from __future__ import annotations

import threading
import time
import os
import socket
import sys

# PyInstaller --windowed does not provide console streams; some dependencies inspect them.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")

import uvicorn
import webview

executable_name = os.path.basename(sys.executable).lower()
edition_argument = next(
    (item.split("=", 1)[1] for item in sys.argv[1:] if item.startswith("--edition=")),
    None,
)
os.environ.setdefault(
    "HEALTHOS_EDITION",
    edition_argument
    or ("cesfam_contralor" if "cesfam" in executable_name else "hospital_operaciones"),
)

from src.backend.desktop_server import app

PORT = int(os.getenv("HEALTHOS_PORT", "8876"))


def run_server() -> None:
    uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="warning")


def wait_until_ready() -> None:
    for _ in range(80):
        try:
            with socket.create_connection(("127.0.0.1", PORT), timeout=0.5):
                return
        except Exception:
            time.sleep(0.2)
    raise RuntimeError("No fue posible iniciar el motor local de HealthOS")


if __name__ == "__main__":
    if os.getenv("HEALTHOS_NO_WINDOW") == "1":
        run_server()
        raise SystemExit(0)
    threading.Thread(target=run_server, daemon=True).start()
    wait_until_ready()
    webview.create_window(
        "HealthOS — Gestión inteligente de listas de espera DM2",
        f"http://127.0.0.1:{PORT}",
        width=1600,
        height=980,
        min_size=(390, 700),
        background_color="#03111f",
    )
    webview.start(gui="edgechromium", private_mode=True)
