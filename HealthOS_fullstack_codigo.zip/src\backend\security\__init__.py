"""Security controls for HealthOS."""
