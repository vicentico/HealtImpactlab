const fs = require('fs');
const path = require('path');
const { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  HeadingLevel, 
  Table, 
  TableRow, 
  TableCell, 
  WidthType, 
  AlignmentType,
  ShadingType
} = require('docx');

async function buildMatrixDocx() {
  const primaryColor = "0F766E"; // Teal 700
  const secondaryColor = "1E293B"; // Slate 800
  const accentColor = "0D9488"; // Teal 600
  const lightBg = "F8FAFC";

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "Arial",
            size: 21,
            color: "334155"
          }
        }
      }
    },
    sections: [{
      properties: {
        page: {
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 }
        }
      },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: "MATRIZ DE CASOS DE USO Y APIS - MVP ECICEP APS",
              bold: true,
              size: 30,
              color: primaryColor
            })
          ]
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: "Documentación Operativa y Contratos para Equipo Backend",
              size: 22,
              bold: true,
              color: secondaryColor
            })
          ],
          space: { after: 300 }
        }),

        new Paragraph({
          text: "1. Catálogo de Casos de Uso del MVP",
          heading: HeadingLevel.HEADING_1,
          space: { before: 200, after: 150 }
        }),

        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              children: [
                new TableCell({ shading: { fill: primaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "CU ID", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: primaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Nombre Caso de Uso", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: primaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Actor Principal", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: primaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Acción Principal", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: primaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Endpoint Backend Asociado", bold: true, color: "FFFFFF" })] })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "CU-01", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Visualización Lista Priorizada DM2" })] }),
                new TableCell({ children: [new Paragraph({ text: "Médico Contralor / Todos" })] }),
                new TableCell({ children: [new Paragraph({ text: "Consulta priorización por CESFAM, sector y nivel de riesgo." })] }),
                new TableCell({ children: [new Paragraph({ text: "GET /api/v1/patients", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "CU-02", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Validación Contralora de Lista" })] }),
                new TableCell({ children: [new Paragraph({ text: "Médico Contralor" })] }),
                new TableCell({ children: [new Paragraph({ text: "Confirma revisión de ficha FCE y firma validez clínica." })] }),
                new TableCell({ children: [new Paragraph({ text: "POST /api/v1/patients/{id}/validate", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "CU-03", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Reordenamiento Excepcional" })] }),
                new TableCell({ children: [new Paragraph({ text: "Médico Contralor" })] }),
                new TableCell({ children: [new Paragraph({ text: "Ajusta posición en lista ingresando nota justificativa auditable." })] }),
                new TableCell({ children: [new Paragraph({ text: "POST /api/v1/patients/{id}/override-position", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "CU-04", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Derivación Nivel 2 Hospitalario" })] }),
                new TableCell({ children: [new Paragraph({ text: "Médico Contralor" })] }),
                new TableCell({ children: [new Paragraph({ text: "Solicita interconsulta a diabetología / nefrología hospitalaria." })] }),
                new TableCell({ children: [new Paragraph({ text: "POST /api/v1/patients/{id}/derive", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "CU-05", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Desenmascaramiento por Excepción" })] }),
                new TableCell({ children: [new Paragraph({ text: "Médico / Enfermería APS" })] }),
                new TableCell({ children: [new Paragraph({ text: "Revela RUT/Nombre en ficha protegida por requerimiento asistencial." })] }),
                new TableCell({ children: [new Paragraph({ text: "POST /api/v1/audit/unmask-event", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "CU-06", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Consulta de Bitácora de Trazabilidad" })] }),
                new TableCell({ children: [new Paragraph({ text: "Auditor / Todos" })] }),
                new TableCell({ children: [new Paragraph({ text: "Visualiza historial inmutable de acciones para auditorías APDP/ANCI." })] }),
                new TableCell({ children: [new Paragraph({ text: "GET /api/v1/audit-logs", bold: true, color: accentColor })] })
              ]
            })
          ]
        }),

        new Paragraph({
          text: "2. Esquema de Entidad 'Paciente' DTO en Base de Datos",
          heading: HeadingLevel.HEADING_1,
          space: { before: 300, after: 150 }
        }),
        new Paragraph({
          text: "Definición técnica de campos requeridos para la base de datos PostgreSQL / Cloud SQL del MVP:",
          space: { after: 150 }
        }),

        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              children: [
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Campo DTO", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Tipo de Dato", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Sensibilidad (Ley 21.719)", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Regla de Negocio / Visualización", bold: true, color: "FFFFFF" })] })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "id", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "UUID / String" })] }),
                new TableCell({ children: [new Paragraph({ text: "Público Interno" })] }),
                new TableCell({ children: [new Paragraph({ text: "Identificador único de sistema" })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "code", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "String (PAC-XXXX)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Seudonimizado" })] }),
                new TableCell({ children: [new Paragraph({ text: "Código de paciente para vistas de lista" })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "name / rut", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "String" })] }),
                new TableCell({ children: [new Paragraph({ text: "DATO SENSIBLE", color: "B91C1C", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Cifrado en reposo. Solo visible para perfil Médico." })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "hbA1c", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Float (% Glicada)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Dato de Salud" })] }),
                new TableCell({ children: [new Paragraph({ text: "Valores >= 10.0% gatillan alerta crítica." })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "priorityScore", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Integer (0 - 100)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Métrica Interna" })] }),
                new TableCell({ children: [new Paragraph({ text: "Calculado dinámicamente según algoritmo ECICEP." })] })
              ]
            })
          ]
        })
      ]
    }]
  });

  const buffer = await Packer.toBuffer(doc);
  const outputPath = path.join(process.cwd(), 'Matriz_Casos_de_Uso_y_APIs_MVP.docx');
  fs.writeFileSync(outputPath, buffer);
  console.log("Matrix document generated successfully at:", outputPath);
}

buildMatrixDocx().catch(err => console.error("Error generating matrix docx:", err));
