const fs = require('fs');
const path = require('path');
const { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  HeadingLevel, 
  Table, 
  TableRow, 
  TableCell, 
  BorderStyle, 
  WidthType, 
  AlignmentType,
  ShadingType
} = require('docx');

async function buildDocx() {
  const primaryColor = "0F766E"; // Teal 700
  const secondaryColor = "1E293B"; // Slate 800
  const accentColor = "0D9488"; // Teal 600
  const lightBg = "F8FAFC"; // Slate 50
  const borderColor = "CBD5E1"; // Slate 300

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "Arial",
            size: 21, // 10.5 pt
            color: "334155"
          }
        }
      }
    },
    sections: [{
      properties: {
        page: {
          margin: {
            top: 1440, // 1 inch
            bottom: 1440,
            left: 1440,
            right: 1440
          }
        }
      },
      children: [
        // Title Header
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: "TORRE DE CONTROL DM2 - ECICEP APS",
              bold: true,
              size: 32,
              color: primaryColor
            })
          ]
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: "Especificación Técnica Backend, Arquitectura MVP & Modelo de Cumplimiento",
              size: 24,
              bold: true,
              color: secondaryColor
            })
          ],
          space: { after: 300 }
        }),

        // Subtitle & Status Box
        new Paragraph({
          children: [
            new TextRun({
              text: "Documento de Ingeniería Inversa & Especificación de APIs para MVP (Sprint 1)",
              italic: true,
              size: 20,
              color: "64748B"
            })
          ],
          space: { after: 400 }
        }),

        // 1. Resumen Ejecutivo MVP
        new Paragraph({
          text: "1. Resumen Ejecutivo y Enfoque MVP Pragático",
          heading: HeadingLevel.HEADING_1,
          space: { before: 200, after: 150 }
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: "El presente documento establece la especificación funcional y técnica derivada del prototipo funcional (MVP) de la "
            }),
            new TextRun({
              text: "Torre de Control DM2 - ECICEP APS",
              bold: true
            }),
            new TextRun({
              text: ". Diseñada bajo la Estrategia de Cuidado Integral Centrado en la Persona (ECICEP) del Ministerio de Salud (MINSAL), esta plataforma permite a los equipos de Atención Primaria priorizar casos de Diabetes Mellitus Tipo 2 (DM2), optimizar la gestión de listas de espera y garantizar el cumplimiento normativo de la Ley N° 21.719 y Ley N° 21.663 mediante Control de Acceso Basado en Roles (RBAC) y seudonimización desde el diseño."
            })
          ],
          space: { after: 200 }
        }),

        // Table: Resumen de Capacidades MVP
        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  shading: { fill: primaryColor, type: ShadingType.CLEAR },
                  children: [new Paragraph({ children: [new TextRun({ text: "Módulo MVP", bold: true, color: "FFFFFF" })] })]
                }),
                new TableCell({
                  shading: { fill: primaryColor, type: ShadingType.CLEAR },
                  children: [new Paragraph({ children: [new TextRun({ text: "Alcance Implementado en Frontend", bold: true, color: "FFFFFF" })] })]
                }),
                new TableCell({
                  shading: { fill: primaryColor, type: ShadingType.CLEAR },
                  children: [new Paragraph({ children: [new TextRun({ text: "Estado para Backend", bold: true, color: "FFFFFF" })] })]
                })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "Torre DM2 Priorizada" })] }),
                new TableCell({ children: [new Paragraph({ text: "Algoritmo de triaje multifactorial (HbA1c, RAC, eventos urgencia, brechas de control)." })] }),
                new TableCell({ children: [new Paragraph({ text: "Listo para API GET /api/v1/patients", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "Seguridad & RBAC" })] }),
                new TableCell({ children: [new Paragraph({ text: "5 perfiles normativos (Médico Contralor, Médico APS, Enfermería, Admin, Auditor)." })] }),
                new TableCell({ children: [new Paragraph({ text: "Listo para Middleware JWT & RBAC", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "Seudonimización (Ley 21.719)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Ocultamiento automático de RUT/Nombre según rol con opción de desenmascaramiento auditado." })] }),
                new TableCell({ children: [new Paragraph({ text: "Listo para Filtros DTO en Backend", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "Acciones Contraloras" })] }),
                new TableCell({ children: [new Paragraph({ text: "Validación de ficha, sobre-escritura justificada de posición y derivación a Nivel 2 Hospitalario." })] }),
                new TableCell({ children: [new Paragraph({ text: "Listo para Endpoints POST con firma", bold: true, color: accentColor })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "Bitácora Auditable ANCI/APDP" })] }),
                new TableCell({ children: [new Paragraph({ text: "Modal con trazabilidad de eventos, timestamp, IP, hash de integridad y descripciones." })] }),
                new TableCell({ children: [new Paragraph({ text: "Listo para servicio AuditLog Persistence", bold: true, color: accentColor })] })
              ]
            })
          ]
        }),

        // 2. Matriz de Roles y Permisos (RBAC)
        new Paragraph({
          text: "2. Matriz de Actores y Permisos (RBAC & Privacidad)",
          heading: HeadingLevel.HEADING_1,
          space: { before: 300, after: 150 }
        }),
        new Paragraph({
          text: "La plataforma implementa un esquema de Control de Acceso Basado en Roles (RBAC) alineado al Principio de Mínimo Privilegio (Ley 21.719):",
          space: { after: 150 }
        }),

        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              children: [
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Rol / Perfil", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Identidad Paciente", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Biomarcadores", bold: true, color: "FFFFFF" })] })] }),
                new TableCell({ shading: { fill: secondaryColor }, children: [new Paragraph({ children: [new TextRun({ text: "Acciones de Contraloría", bold: true, color: "FFFFFF" })] })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "MÉDICO_CONTRALOR", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Completa (Nombre + RUT)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Detalle completo (HbA1c %)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Validar, Reordenar, Derivar N2", color: primaryColor, bold: true })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "MEDICO_APS", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Completa (Sector)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Detalle clínico completo" })] }),
                new TableCell({ children: [new Paragraph({ text: "Lectura & Atención Directa" })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "ENFERMERIA_APS", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Seudonimizada (Iniciales + Cód)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Detalle completo" })] }),
                new TableCell({ children: [new Paragraph({ text: "Triaje & Seguimiento Glicemia" })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "ADMINISTRATIVO", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Seudonimizada (Iniciales)" })] }),
                new TableCell({ children: [new Paragraph({ text: "Oculto / Meta Categórica" })] }),
                new TableCell({ children: [new Paragraph({ text: "Gestión de Agenda y Citas" })] })
              ]
            }),
            new TableRow({
              children: [
                new TableCell({ children: [new Paragraph({ text: "AUDITOR_LECTURA", bold: true })] }),
                new TableCell({ children: [new Paragraph({ text: "Seudonimizada" })] }),
                new TableCell({ children: [new Paragraph({ text: "Lectura de Muestra" })] }),
                new TableCell({ children: [new Paragraph({ text: "Ver Bitácora de Trazabilidad" })] })
              ]
            })
          ]
        }),

        // 3. Especificación de Contratos de API REST (Backend)
        new Paragraph({
          text: "3. Especificación de Endpoints y Contratos de API (Backend MVP)",
          heading: HeadingLevel.HEADING_1,
          space: { before: 300, after: 150 }
        }),

        new Paragraph({
          text: "A continuación se especifican los contratos JSON requeridos para conectar la plataforma frontend con el servidor de producción:",
          space: { after: 150 }
        }),

        // Endpoint 1
        new Paragraph({
          children: [
            new TextRun({ text: "Endpoint 1: Obtenedor de Pacientes Priorizados", bold: true, size: 22, color: primaryColor })
          ],
          space: { before: 150, after: 50 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "GET /api/v1/patients", bold: true }),
            new TextRun({ text: " (Parámetros: ?datasetId=cesfam-ariztia&sector=Azul&sortBy=prioridad_actual)" })
          ],
          space: { after: 100 }
        }),
        new Paragraph({
          text: "Ejemplo de Payload JSON de Respuesta (Respetando Seudonimización según Rol JWT):",
          space: { after: 50 }
        }),
        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  shading: { fill: lightBg },
                  children: [
                    new Paragraph({
                      children: [
                        new TextRun({
                          text: `[
  {
    "id": "pat-001",
    "code": "PAC-8941",
    "initials": "J.P.M.",
    "name": "Juan Pablo Morales Rojas", // Oculto en roles seudonimizados
    "rut": "12.845.902-3",            // Parcializado en roles seudonimizados
    "partialRut": "12.845.***-*",
    "age": 64,
    "gender": "M",
    "sector": "Sector Azul",
    "currentPosition": 1,
    "originalPosition": 4,
    "priorityScore": 94,
    "riskLevel": "MUY_ALTA",
    "clinicalFactors": {
      "hbA1c": 11.2,
      "rac": "340 mg/g (Macroalbuminuria)",
      "lastControlMonthsAgo": 8,
      "recentEmergencyEvents": ["SAPU Hiperglicemia 15-Jul", "Urgencia HCH 02-Ago"]
    },
    "contralorValidation": {
      "isValidated": true,
      "validatedBy": "Dr. Roberto Silva (Médico Contralor)",
      "validatedAt": "2026-08-04T16:30:00Z"
    }
  }
]`,
                          font: "Courier New",
                          size: 16
                        })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        }),

        // Endpoint 2: Validar Priorización
        new Paragraph({
          children: [
            new TextRun({ text: "Endpoint 2: Validación Contralora de Paciente", bold: true, size: 22, color: primaryColor })
          ],
          space: { before: 200, after: 50 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "POST /api/v1/patients/{id}/validate", bold: true })
          ],
          space: { after: 100 }
        }),
        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  shading: { fill: lightBg },
                  children: [
                    new Paragraph({
                      children: [
                        new TextRun({
                          text: `// Request Payload:
{
  "notes": "Priorización DM2 ECICEP auditada y validada por Médico Contralor.",
  "contralorId": "usr-901"
}

// Response Payload (200 OK):
{
  "status": "success",
  "message": "Ficha validada correctamente y registrada en bitácora de trazabilidad.",
  "timestamp": "2026-08-05T14:10:00Z",
  "auditLogId": "log-8841"
}`,
                          font: "Courier New",
                          size: 16
                        })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        }),

        // 4. Cumplimiento Normativo & Ciberseguridad
        new Paragraph({
          text: "4. Marco de Cumplimiento & Privacidad por Diseño",
          heading: HeadingLevel.HEADING_1,
          space: { before: 300, after: 150 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "• Ley N° 21.719 (Protección de Datos Personales): ", bold: true }),
            new TextRun({ text: "Cumple con el Principio de Minimización de Datos y Privacidad por Defecto. Las respuestas API entregan datos seudonimizados a perfiles no autorizados, evitando la filtración masiva de RUN/Nombres." })
          ],
          space: { after: 100 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "• Ley N° 21.663 (Ciberseguridad & ANCI): ", bold: true }),
            new TextRun({ text: "Cada cambio de estado, override de posición o acceso a datos sensibles genera un registro inmutable en la bitácora con Timestamp, IP, Rol y Hash de integridad." })
          ],
          space: { after: 100 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: "• Estrategia ECICEP MINSAL: ", bold: true }),
            new TextRun({ text: "Priorización orientada al Modelo de Cuidado Integral, integrando factores multiorgánicos y determinantes territoriales de salud en la APS." })
          ],
          space: { after: 200 }
        }),

        // Footer Note
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: "Documento generado automáticamente para la arquitectura Backend MVP de la Torre de Control DM2 - ECICEP.",
              italic: true,
              size: 18,
              color: "94A3B8"
            })
          ],
          space: { before: 400 }
        })
      ]
    }]
  });

  const buffer = await Packer.toBuffer(doc);
  const outputPath = path.join(process.cwd(), 'Especificacion_Tecnica_Backend_MVP_ECICEP.docx');
  fs.writeFileSync(outputPath, buffer);
  console.log("Document generated successfully at:", outputPath);
}

buildDocx().catch(err => console.error("Error generating docx:", err));
